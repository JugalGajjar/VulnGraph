import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileRead {

    public static void main(String[] args) {
        String fileName = args[0]; // User input - vulnerable to Path Traversal

        try {
            File file = new File(fileName);
            FileInputStream fis = new FileInputStream(file);
            
            int data;
            while ((data = fis.read()) != -1) {
                System.out.print((char) data);
            }
            
            fis.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}