import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter file name:");
        String fileName = scanner.nextLine();
        
        File file = new File(fileName);
        
        try {
            if (file.exists()) {
                System.out.println("File exists!");
                // Do something with the file
            } else {
                System.out.println("File not found!");
            }
        } catch (IOException e) {
            System.out.println("Error accessing file.");
            e.printStackTrace();
        }
        
        scanner.close();
    }
}