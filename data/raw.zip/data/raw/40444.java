import java.util.concurrent.TimeUnit;

public class RetryableTaskExecutor {
    public static void main(String[] args) {
        RetryableTaskExecutor executor = new RetryableTaskExecutor();
        executor.execute(() -> {
            System.out.println("Task executed");
            return true;
        }, 3, TimeUnit.SECONDS.toMillis(1));
    }

    public boolean execute(RetryableTask task, int maxAttempts, long retryDelayMillis) {
        int attempt = 0;
        while (attempt < maxAttempts) {
            try {
                if (task.execute()) {
                    return true;
                }
            } catch (Exception e) {
                System.err.println("Task execution failed: " + e.getMessage());
            }
            attempt++;
            if (attempt < maxAttempts) {
                try {
                    Thread.sleep(retryDelayMillis);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Interrupted while waiting for retry", e);
                }
            }
        }
        return false;
    }

    @FunctionalInterface
    interface RetryableTask {
        boolean execute() throws Exception;
    }
}