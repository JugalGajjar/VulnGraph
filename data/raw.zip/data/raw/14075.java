import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {

    public static void main(String[] args) {
        try {
            // Taking user input for the command to execute
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String command = br.readLine();

            // Executing the user input command using Runtime.getRuntime().exec()
            Process process = Runtime.getRuntime().exec(command);

            // Reading and printing the output of the executed command
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}