import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String command = reader.readLine();
            
            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec(command);
            
            BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String outputLine;
            
            while ((outputLine = outputReader.readLine()) != null) {
                System.out.println(outputLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}