import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = args[0]; // Assume user provides input as "../etc/passwd"
        String fileToRead = "/var/data/" + userInput; // Vulnerable code: Concatenating user input directly into the file path

        try (BufferedReader br = new BufferedReader(new FileReader(fileToRead))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

}