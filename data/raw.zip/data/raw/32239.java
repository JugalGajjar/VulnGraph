import java.io.*;

public class XSSVulnerableCode {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter your name: ");
            String name = br.readLine();

            System.out.println("Hello, " + name + "!"); // Vulnerability here

        } catch (IOException e) {
            System.err.println("Error reading input!");
        }
    }
}