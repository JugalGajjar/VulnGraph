import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input received from a form field or any external source
        String userInput = "<script>alert('XSS Vulnerability')</script>";

        // Improperly handling user input by directly outputting it to a web page
        System.out.println("<div>" + userInput + "</div>");
    }
}