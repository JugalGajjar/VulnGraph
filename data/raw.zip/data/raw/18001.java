import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        
        // Improper handling of user input without proper sanitization
        String output = "<p>User Input: " + userInput + "</p>";
        
        PrintWriter out = response.getWriter();
        out.println(output);
    }
}