import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter your name: ");
            String name = br.readLine();
            
            System.out.println("Hello, " + name + "!"); // Vulnerable code
            
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
    }
}