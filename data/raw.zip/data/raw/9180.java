import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class XSSVulnerableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userInput = request.getParameter("input");
        String output = "Hello, " + userInput + "!";

        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + output + "</h1>");
        out.println("</body></html>");
    }
}