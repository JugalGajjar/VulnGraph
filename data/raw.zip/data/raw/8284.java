import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerability {

    public static void main(String[] args) {
        try {
            // Taking user input for the command to execute
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String userInput = reader.readLine();

            // Executing the command using Runtime.exec()
            Process process = Runtime.getRuntime().exec("ping " + userInput);

            // Reading and printing the output of the command
            BufferedReader inputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = inputReader.readLine()) != null) {
                System.out.println(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}