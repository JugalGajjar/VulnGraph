import java.io.*;
import java.util.*;

public class XSSVulnerableCode {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String userInput = scanner.nextLine();

        // Improperly handling user input by directly outputting it without sanitization
        System.out.println("Hello, " + userInput + "!");

        scanner.close();
    }
}