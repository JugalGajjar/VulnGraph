import java.util.Scanner;

public class BufferOverflowVulnerability {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        
        // Vulnerable code - allocating a fixed-size buffer
        byte[] buffer = new byte[10];
        
        // Copying the user input into the buffer without proper bounds checking
        byte[] userInputBytes = name.getBytes();
        for (int i = 0; i < userInputBytes.length; i++) {
            buffer[i] = userInputBytes[i];
        }
        
        System.out.println("Hello, " + new String(buffer));
    }
}