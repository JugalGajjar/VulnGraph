import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileLineCounter {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java FileLineCounter <file-path>");
            System.exit(1);
        }

        Path path = Paths.get(args[0]);

        if (!Files.exists(path)) {
            System.err.println("File does not exist: " + path);
            System.exit(1);
        }
        if (!Files.isRegularFile(path)) {
            System.err.println("Not a regular file: " + path);
            System.exit(1);
        }
        if (!Files.isReadable(path)) {
            System.err.println("File not readable: " + path);
            System.exit(1);
        }

        try (Stream<String> lines = Files.lines(path)) {
            long count = lines.count();
            System.out.println("Number of lines: " + count);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            System.exit(1);
        }
    }
}