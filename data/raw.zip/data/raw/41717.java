package com.haiku.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Objects;

/**
 * Validates, normalizes and enriches Japanese haiku poems according to the classical 5-7-5 morae rule
 * while performing inline furigana annotation and kigo (season word) extraction via regular expressions.
 * 
 * NOTE: This utility treats full-width Japanese punctuation as morae neutral and supports both
 * modern orthography and historical kana usage.  Morae counting is approximative  aimed at
 * rapid validation rather than linguistic accuracy  yet sufficient for creative tooling.
 */
public final class HaikuRegexEngine {

    private static final Pattern KANA_BLOCK =
            Pattern.compile("[\u3040-\u309F\u30A0-\u30FF?]+");

    /** Kigo candidates  season words catalogued by lunar calendar month (1-index)  encoded in one compact alternation */
    private static final Pattern KIGO =
            Pattern.compile("(?<kigo>?|?|?|?|?|???|??|?|?|?|??|?|???|??|???)", Pattern.UNICODE_CHARACTER_CLASS);

    /** Rough mora counter using kana + small-tsu/small-y vowel doubling rules */
    private static final Pattern MORA_COUNT =
            Pattern.compile("(?:" +
                    "[\u3040-\u309F\u30A0-\u30FF?]|" +                   // kana & prolonged sound mark
                    "[??????]|" +                                    // small ya-yu-yo as extra mora
                    "?|?" +                                            // small tsu doubles consonant -> +1 mora
                    ")+", Pattern.UNICODE_CHARACTER_CLASS);

    private HaikuRegexEngine() {
        throw new AssertionError("static utility");
    }

    /**
     * Validates a haiku's 5-7-5 structure and enriches it with inline kigo annotations.
     *
     * @param rawHaiku three-line haiku delimited by \n
     * @return parsed, annotated haiku
     * @throws IllegalArgumentException if mora count deviates or input is null
     */
    public static AnnotatedHaiku parse(String rawHaiku) {
        Objects.requireNonNull(rawHaiku, "haiku text required");
        String[] lines = rawHaiku.trim().split("\\R", 3);
        if (lines.length != 3) {
            throw new IllegalArgumentException("haiku must have exactly 3 lines");
        }

        int[] morae = new int[3];
        String[] annotatedLines = new String[3];

        for (int i = 0; i < 3; i++) {
            String line = lines[i].replaceAll("[??!?????()·]", "");
            Matcher m = MORA_COUNT.matcher(line);
            morae[i] = 0;
            while (m.find()) {
                for (char c : m.group().toCharArray()) {
                    if (c == '?' || c == '?' || c == '?' || c == '?' || c == '?' || c == '?' || c == '?' || c == '?') {
                        morae[i] += 1; // extra moraic element
                    } else {
                        morae[i] += 1;
                    }
                }
            }

            // append kigo annotation as furigana
            Matcher kigoMatcher = KIGO.matcher(line);
            StringBuffer sb = new StringBuffer();
            while (kigoMatcher.find()) {
                kigoMatcher.appendReplacement(sb, "<ruby>$1<rt>??</rt></ruby>");
            }
            kigoMatcher.appendTail(sb);
            annotatedLines[i] = sb.toString();
        }

        int[] expected = {5, 7, 5};
        for (int i = 0; i < 3; i++) {
            if (morae[i] != expected[i]) {
                throw new IllegalArgumentException(
                        String.format("line %d has %d morae, expected %d", i + 1, morae[i], expected[i]));
            }
        }

        return new AnnotatedHaiku(annotatedLines[0], annotatedLines[1], annotatedLines[2]);
    }

    /**
     * Immutable result object carrying the annotated haiku lines.
     */
    public static final class AnnotatedHaiku {
        public final String first;
        public final String second;
        public final String third;

        private AnnotatedHaiku(String first, String second, String third) {
            this.first = first;
            this.second = second;
            this.third = third;
        }

        @Override
        public String toString() {
            return first + "\n" + second + "\n" + third;
        }
    }
}