import java.io.IOException;
import java.io.PrintWriter;

public class XssVulnerableCode {
    public static void main(String[] args) {
        String userInput = "<script>alert('XSS Vulnerability')</script>";

        // Improperly handling user input without sanitization
        String output = "Welcome, " + userInput;

        try {
            PrintWriter out = new PrintWriter("output.html");
            out.println("<html><body>");
            out.println(output);
            out.println("</body></html>");
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}