import java.io.*;

public class XSSVulnerableCode {

    public static void main(String[] args) {
        String userInput = "<script>alert('XSS Vulnerability!')</script>";
        
        // Improperly handling user input by directly outputting it to a web page
        System.out.println("<div>" + userInput + "</div>");
    }
}