import java.io.IOException;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        String htmlResponse = "<html><body><p>User input: " + userInput + "</p></body></html>";

        response.getWriter().write(htmlResponse);
    }
}