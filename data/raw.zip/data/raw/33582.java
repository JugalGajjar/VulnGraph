import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the IP address to ping: ");
            String ipAddress = reader.readLine();

            // Vulnerable code - user input directly passed to the command
            Process process = Runtime.getRuntime().exec("ping " + ipAddress);

            BufferedReader inputStream = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String output = "";
            while ((output = inputStream.readLine()) != null) {
                System.out.println(output);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}