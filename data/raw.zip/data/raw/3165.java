import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a directory name to list its files: ");
        String directoryName = reader.readLine();
        
        // Vulnerability: User input is directly passed to the command without proper validation
        String command = "ls " + directoryName;
        
        Process process = Runtime.getRuntime().exec(command);
        BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        
        String line;
        while ((line = outputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}