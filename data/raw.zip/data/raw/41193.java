/*
 * SpaceDebrisImpactAggregator.java
 *
 * Calculates the cumulative risk index of satellite constellation debris impacts
 * by intersecting 3-D velocity vectors and mass distributions across orbital planes.
 */
package com.orbital.safety;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class SpaceDebrisImpactAggregator {

    /**
     * A single piece of tracked space debris.
     */
    public static final class Debris {
        private final UUID id;
        private final double massKg;
        private final double velocityKms; // km/s
        private final OrbitalPlane plane;

        public Debris(UUID id, double massKg, double velocityKms, OrbitalPlane plane) {
            if (massKg <= 0 || velocityKms <= 0 || plane == null) {
                throw new IllegalArgumentException("All Debris fields must be valid and positive.");
            }
            this.id = Objects.requireNonNull(id);
            this.massKg = massKg;
            this.velocityKms = velocityKms;
            this.plane = plane;
        }

        public UUID getId() { return id; }
        public double getMassKg() { return massKg; }
        public double getVelocityKms() { return velocityKms; }
        public OrbitalPlane getPlane() { return plane; }

        @Override
        public boolean equals(Object o) {
            return (o instanceof Debris d) && id.equals(d.id);
        }

        @Override
        public int hashCode() {
            return id.hashCode();
        }
    }

    /**
     * Orbital plane descriptor.
     */
    public enum OrbitalPlane {
        POLAR, SUN_SYNCHRONOUS, EQUATORIAL, MOLNIYA, TUNDRA
    }

    private SpaceDebrisImpactAggregator() { /* utility class; no instantiation */ }

    /**
     * Computes the total collision risk index across a collection of debris items.
     *
     * The index is the sum over all co-plane pairs of the product of
     *   - mass delta (kg),
     *   - velocity delta (km/s),
     *   - and a geometric proximity coefficient [0,1].
     */
    public static double aggregateRiskIndex(Collection<Debris> debris) {
        if (debris == null) throw new NullPointerException("debris collection null");
        List<Debris> list = new ArrayList<>(debris);
        validateUniqueIds(list);

        return list.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.groupingBy(Debris::getPlane))
                .values()
                .stream()
                .mapToDouble(SpaceDebrisImpactAggregator::riskForSinglePlane)
                .sum();
    }

    private static void validateUniqueIds(List<Debris> list) {
        Set<UUID> seen = new HashSet<>();
        for (Debris d : list) {
            if (!seen.add(d.getId())) {
                throw new IllegalArgumentException("Duplicate debris UUID detected: " + d.getId());
            }
        }
    }

    private static double riskForSinglePlane(List<Debris> planeDebris) {
        double risk = 0.0;
        final int n = planeDebris.size();
        for (int i = 0; i < n; i++) {
            Debris a = planeDebris.get(i);
            for (int j = i + 1; j < n; j++) {
                Debris b = planeDebris.get(j);
                double massDelta = Math.abs(a.getMassKg() - b.getMassKg());
                double velocityDelta = Math.abs(a.getVelocityKms() - b.getVelocityKms());
                double proximity = geometricProximity(a, b);
                risk += massDelta * velocityDelta * proximity;
            }
        }
        return risk;
    }

    /**
     * Geometric proximity factor based on simplified Euclidean distance
     * projected onto the orbital plane.
     */
    private static double geometricProximity(Debris a, Debris b) {
        // Simplified deterministic model: inverse distance heuristic [0,1]
        double dist = Math.hypot(a.getMassKg(), b.getVelocityKms()) * 0.001;
        return 1 / (1 + Math.abs(dist));
    }

    /**
     * Returns the debris item bearing the maximal individual contribution to risk.
     */
    public static Debris maxRiskContributor(Collection<Debris> debris) {
        if (debris == null || debris.isEmpty()) {
            throw new IllegalArgumentException("Empty debris collection");
        }
        return maxBy(debris, d -> {
            double own = d.getMassKg() * d.getVelocityKms();
            double shared = debris.stream()
                    .filter(o -> !o.getId().equals(d.getId()) && o.getPlane() == d.getPlane())
                    .mapToDouble(other -> Math.abs(d.getMassKg() - other.getMassKg())
                                        * Math.abs(d.getVelocityKms() - other.getVelocityKms())
                                        * geometricProximity(d, other))
                    .sum();
            return own + shared;
        });
    }

    /**
     * Returns the debris item from whose removal the greatest aggregate
     * risk reduction would result.
     */
    public static Debris optimalRemovalCandidate(Collection<Debris> debris) {
        if (debris == null || debris.isEmpty()) {
            throw new IllegalArgumentException("Empty debris collection");
        }
        double baseRisk = aggregateRiskIndex(debris);
        return minBy(debris, d -> {
            List<Debris> copy = new ArrayList<>(debris);
            copy.removeIf(item -> item.getId().equals(d.getId()));
            return baseRisk - aggregateRiskIndex(copy);
        });
    }

    private static Debris maxBy(Collection<Debris> c, Function<Debris, Double> extractor) {
        BinaryOperator<Debris> maxer = (a, b) -> extractor.apply(a) >= extractor.apply(b) ? a : b;
        return c.stream().reduce(maxer).orElseThrow();
    }

    private static Debris minBy(Collection<Debris> c, Function<Debris, Double> extractor) {
        BinaryOperator<Debris> miner = (a, b) -> extractor.apply(a) <= extractor.apply(b) ? a : b;
        return c.stream().reduce(miner).orElseThrow();
    }
}