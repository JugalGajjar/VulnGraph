import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = "../secretFile.txt";
        
        try {
            File file = new File("data/" + userInput);
            FileInputStream fis = new FileInputStream(file);
            
            int content;
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }
            
            fis.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}