package com.axionics.hydroponics;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Tracks and schedules nutrient ion replenishment for deep-water hydroponic chambers
 * to maintain optimal electro-conductivity (EC) drift patterns based on plant pheno-stage.
 */
public final class IonReplenisher<T extends IonReplenisher.IonicSolution> {

    /** Electro-conductivity target window in mS/cm */
    private final double targetLowerEc;
    private final double targetUpperEc;

    /** Drift slope threshold per hour (mS²·cm?¹·h?¹) */
    private final double maxDriftSlope;

    private final List<Schedule<T>> queue = new ArrayList<>();

    public IonReplenisher(double targetLowerEc, double targetUpperEc, double maxDriftSlope) {
        if (targetLowerEc < 0 || targetUpperEc < 0 || targetLowerEc >= targetUpperEc) {
            throw new IllegalArgumentException("Invalid EC bounds");
        }
        this.targetLowerEc = targetLowerEc;
        this.targetUpperEc = targetUpperEc;
        this.maxDriftSlope = Math.abs(maxDriftSlope);
    }

    /**
     * @return true if an adjustment was actually scheduled
     */
    public boolean schedule(T solution, Instant when) {
        Objects.requireNonNull(solution, "solution");
        Objects.requireNonNull(when, "when");

        if (!isValidDriftPrediction(solution)) {
            throw new IllegalArgumentException("Drift prediction data missing");
        }

        queue.add(new Schedule<>(solution, when));
        Collections.sort(queue);
        return true;
    }

    /** Retrieves the next scheduled solution without removing it. */
    public T peekNext() {
        return queue.isEmpty() ? null : queue.get(0).solution();
    }

    /** Retrieves and removes the next scheduled solution. */
    public T popNext() {
        return queue.isEmpty() ? null : queue.remove(0).solution();
    }

    /** Returns the drift-corrected EC value projected at the given instant. */
    public double projectEc(T solution, Instant at) {
        long elapsedMs = Math.max(0, at.toEpochMilli() - solution.recordedAt().toEpochMilli());
        double slope = solution.driftSlopeMsCmPerHour();
        return solution.currentEc() + slope * (elapsedMs / 3_600_000.0);
    }

    private boolean isValidDriftPrediction(T solution) {
        return solution.driftSlopeMsCmPerHour() >= -maxDriftSlope && solution.driftSlopeMsCmPerHour() <= maxDriftSlope;
    }

    public record Schedule<T>(T solution, Instant instant) implements Comparable<Schedule<T>> {
        @Override public int compareTo(Schedule<T> other) {
            return this.instant.compareTo(other.instant);
        }
    }

    public interface IonicSolution {
        double currentEc();
        double driftSlopeMsCmPerHour();
        Instant recordedAt();
    }
}