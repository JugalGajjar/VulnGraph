import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String fileName = args[0]; // User input containing the file name

        try {
            File file = new File("/path/to/files/" + fileName); // Vulnerable code: Concatenating user input with the file path
            FileInputStream fis = new FileInputStream(file);

            // Read and output the contents of the file
            int content;
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }

            fis.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}