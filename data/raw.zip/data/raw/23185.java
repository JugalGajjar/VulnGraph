import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input from an untrusted source
        String userInput = "<script>alert('XSS Vulnerability!')</script>";

        // Improperly handling user input by directly outputting it to an HTML response
        String htmlResponse = "<html><body>Welcome, " + userInput + "</body></html>";
        
        // Output the HTML response to the console (simulating sending it to a web browser)
        System.out.println(htmlResponse);
    }
}