import java.io.IOException;
import java.io.PrintWriter;

public class XSSVulnerableCode {

    public static void main(String[] args) {
        String userInput = "<script>alert('XSS Attack!')</script>";

        // Improperly handling user input by directly printing it to an HTML response
        PrintWriter out = new PrintWriter(System.out);
        out.println("<p>User Input: " + userInput + "</p>");
    }
}