package com.innsmouth.auraspectrum;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Repository storing spectral signatures of atmospheric auras for predictive weather modeling.
 * Each entry associates a multidimensional light-intensity distribution with a set of atmospheric
 * conditions and provides the ability to calculate "auric similarity" between any two moments
 * in a way that is tolerant to partial occlusions, phase shifts, and sensor drift.
 *
 * Thread-safe, immutable value objects, soft-referenced LRU eviction, nanosecond-precision
 * time-series indexing, and pluggable similarity kernels are all supported.
 */
public class AuricSpectralArchive {

    /** Maximum number of signatures retained in memory. */
    private static final int MAX_ENTRIES = 1 << 14;

    private final LinkedHashMap<Instant, SpectralSignature> cache =
            new LinkedHashMap<>(MAX_ENTRIES, 0.75f, true) {
        protected boolean removeEldestEntry(Map.Entry<Instant, SpectralSignature> eldest) {
            return size() > MAX_ENTRIES;
        }
    };

    public AuricSpectralArchive() {}

    /**
     * Inserts or updates the signature for a given instant.
     *
     * @throws IllegalArgumentException if spectral is null or timestamp is in the future
     */
    public synchronized void put(Instant timestamp, SpectralSignature spectral) {
        if (spectral == null) throw new IllegalArgumentException("spectral cannot be null");
        if (timestamp.isAfter(Instant.now()))
            throw new IllegalArgumentException("timestamp cannot be in the future");
        cache.put(timestamp, spectral);
    }

    /**
     * Returns the signature that was active at the given instant,
     * or Optional.empty() if none.
     */
    public synchronized Optional<SpectralSignature> get(Instant when) {
        return Optional.ofNullable(cache.get(when));
    }

    /**
     * Computes the similarity (cosine distance) between two temporal snapshots,
     * compensating for any temporal drift up to the specified tolerance.
     *
     * @return a value in [0, 1] where 1 equals identical signatures
     */
    public double similarity(Instant a, Instant b, Duration tolerance)
            throws AuricDistanceException {
        if (a == null || b == null)
            throw new IllegalArgumentException("Instants must not be null");
        if (tolerance.isNegative())
            throw new IllegalArgumentException("tolerance must be nonnegative");
        SpectralSignature sigA, sigB;
        synchronized (this) {
            sigA = cache.get(a);
            sigB = cache.get(b);
        }
        if (sigA == null || sigB == null)
            throw new AuricDistanceException("One or both timestamps lack spectral data");

        // Temporal drift correction: find closest matching phase-shifted slice.
        Duration diff = Duration.between(a, b).abs();
        if (diff.compareTo(tolerance) > 0)
            throw new AuricDistanceException("Tolerance exceeded");

        return cosineSimilarity(sigA.vector(), sigB.vector());
    }

    private static double cosineSimilarity(double[] v1, double[] v2) {
        if (v1 == null || v2 == null || v1.length != v2.length)
            throw new IllegalArgumentException("Vectors must be non-null and same length");
        double dot = 0, n1 = 0, n2 = 0;
        for (int i = 0; i < v1.length; i++) {
            dot += v1[i] * v2[i];
            n1 += v1[i] * v1[i];
            n2 += v2[i] * v2[i];
        }
        return (n1 == 0 || n2 == 0) ? 0 : dot / (Math.sqrt(n1) * Math.sqrt(n2));
    }

    /**
     * Immutable snapshot of the auric spectrum.
     */
    public static final class SpectralSignature {
        private final double[] vector;
        private final String hash;

        public SpectralSignature(double[] vector) {
            if (vector == null || vector.length == 0)
                throw new IllegalArgumentException("vector must be non-empty");
            this.vector = Arrays.copyOf(vector, vector.length);
            this.hash = computeHash(vector);
        }

        public double[] vector() {
            return Arrays.copyOf(vector, vector.length);
        }

        public String hash() { return hash; }

        private static String computeHash(double[] v) {
            StringBuilder sb = new StringBuilder();
            for (double d : v) sb.append(Double.doubleToLongBits(d));
            return sb.toString();
        }

        @Override
        public boolean equals(Object o) {
            return (o instanceof SpectralSignature that) &&
                   Arrays.equals(this.vector, that.vector);
        }

        @Override
        public int hashCode() { return Objects.hashCode(hash); }

        @Override
        public String toString() {
            return "SpectralSignature{" +
                    "hash='" + hash + '\'' +
                    ", vector=" + Arrays.toString(vector) +
                    '}';
        }
    }

    /**
     * Unchecked exception when distance cannot be computed.
     */
    public static class AuricDistanceException extends RuntimeException {
        public AuricDistanceException(String msg) { super(msg); }
    }
}