import java.util.Scanner;

public class BufferOverflowExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String input = scanner.next();
        
        // This code snippet is vulnerable to buffer overflow
        char[] buffer = new char[10];
        input.getChars(0, input.length(), buffer, 0);
        
        System.out.println("Buffer contents: " + new String(buffer));
    }
}