import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XSSVulnerableCode {

    public void vulnerableMethod(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        
        // Improper handling of user input, vulnerable to XSS
        String output = "<div>" + userInput + "</div>";
        
        response.getWriter().write(output);
    }
}