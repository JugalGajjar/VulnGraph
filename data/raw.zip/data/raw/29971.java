import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        // Vulnerable code - allowing path traversal by manipulating user input
        File file = new File("/path/to/directory/" + fileName);
        
        if (file.exists()) {
            try {
                byte[] fileContent = Files.readAllBytes(file.toPath());
                System.out.println(new String(fileContent));
            } catch (IOException e) {
                System.err.println("Error reading file content");
            }
        } else {
            System.out.println("File not found");
        }

        scanner.close();
    }
}