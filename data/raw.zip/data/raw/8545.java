import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a file name: ");
        String fileName = reader.readLine();
        
        // This code is vulnerable to command injection
        String command = "ls -l " + fileName;
        
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader processOutputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = processOutputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}