import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.NoSuchFileException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class FileHasher {

    public static String computeSHA256(String filePath) throws IOException, NoSuchAlgorithmException {
        if (filePath == null || filePath.isBlank()) {
            throw new IllegalArgumentException("File path must not be null or blank");
        }
        return computeSHA256(Path.of(filePath));
    }

    public static String computeSHA256(Path path) throws IOException, NoSuchAlgorithmException {
        if (path == null) {
            throw new IllegalArgumentException("Path must not be null");
        }
        if (!Files.exists(path)) {
            throw new NoSuchFileException("File does not exist: " + path);
        }
        if (!Files.isRegularFile(path)) {
            throw new IllegalArgumentException("Not a regular file: " + path);
        }
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] fileBytes = Files.readAllBytes(path);
        byte[] hashBytes = digest.digest(fileBytes);
        return bytesToHex(hashBytes);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder(2 * bytes.length);
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1)
                hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java FileHasher <file-path>");
            System.exit(1);
        }
        try {
            String hash = computeSHA256(args[0]);
            System.out.println("SHA-256: " + hash);
        } catch (IllegalArgumentException | NoSuchFileException e) {
            System.err.println("Input error: " + e.getMessage());
            System.exit(2);
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Algorithm not available: " + e.getMessage());
            System.exit(3);
        } catch (IOException e) {
            System.err.println("I/O error: " + e.getMessage());
            System.exit(4);
        }
    }
}