import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter your name: ");
            String userInput = br.readLine();

            System.out.println("Hello, " + userInput + "!"); // Vulnerable code

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}