import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionDemo {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a hostname to ping: ");
        String hostname = reader.readLine();
        
        String command = "ping " + hostname;
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader processOutputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = processOutputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}