import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.nio.file.Paths;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = "../../../../../etc/passwd";
        String directory = "/var/www/files/";

        String filePath = directory + userInput;

        try {
            File file = new File(filePath);
            if (file.exists()) {
                byte[] fileData = Files.readAllBytes(Paths.get(filePath));
                System.out.println(new String(fileData));
            } else {
                System.out.println("File not found.");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}