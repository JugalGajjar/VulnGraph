import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PathTraversalVulnerability {
    public static void main(String[] args) {
        String userProvidedFilename = "../secretFile.txt"; // User input with potential path traversal

        try {
            String basePath = "/home/user/public/";
            String filePath = basePath + userProvidedFilename;

            File file = new File(filePath);
            if(file.exists()) {
                byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
                System.out.println("File content: " + new String(fileContent));
            } else {
                System.out.println("File not found.");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}