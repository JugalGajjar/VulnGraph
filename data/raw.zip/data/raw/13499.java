import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head><title>XSS Vulnerable Page</title></head>");
        out.println("<body>");
        // This line does not properly sanitize userInput and can lead to XSS vulnerability
        out.println("User Input: " + userInput);
        out.println("</body>");
        out.println("</html>");
    }
}