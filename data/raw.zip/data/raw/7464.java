import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class InputHandler extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userInput = request.getParameter("input");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("User input: " + userInput); // User input is directly embedded in the response
        out.println("</body>");
        out.println("</html>");
    }
}