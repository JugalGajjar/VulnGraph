import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XSSVulnerableServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        
        // Vulnerable code: directly outputting user input without proper encoding
        PrintWriter out = response.getWriter();
        out.println("<html><body>User input: " + userInput + "</body></html>");
    }
}