import java.util.InputMismatchException;
import java.util.Scanner;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Temperature Converter");
                System.out.println("1. Celsius to Fahrenheit");
                System.out.println("2. Fahrenheit to Celsius");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");
                int option = scanner.nextInt();
                if (option == 3) {
                    break;
                } else if (option < 1 || option > 3) {
                    System.out.println("Invalid option. Please choose a valid option.");
                    continue;
                }
                System.out.print("Enter temperature value: ");
                double temperature = scanner.nextDouble();
                if (option == 1) {
                    double fahrenheit = convertCelsiusToFahrenheit(temperature);
                    System.out.printf("%.2f?C is equal to %.2f?F%n", temperature, fahrenheit);
                } else if (option == 2) {
                    double celsius = convertFahrenheitToCelsius(temperature);
                    System.out.printf("%.2f?F is equal to %.2f?C%n", temperature, celsius);
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next();
            }
        }
        scanner.close();
    }

    private static double convertCelsiusToFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    private static double convertFahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }
}