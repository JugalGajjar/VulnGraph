package io.onedev.server.product;

public class Test {

	@org.junit.Test
	public void test() {
	}		

}