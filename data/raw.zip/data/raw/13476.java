import java.io.*;

public class XSSVulnerableCode {

    public static void main(String[] args) {
        // Simulating user input received from a form or any input source
        String userInput = "<script>alert('XSS Vulnerability!')</script>";

        // Improperly handling user input by directly printing it to an HTML response
        System.out.println("<div>" + userInput + "</div>");
    }
}