import java.io.*;

public class XSSExample {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter your name: ");
        String name = reader.readLine();
        
        System.out.println("Hello, " + name + "!"); // Vulnerability here
        
    }
}