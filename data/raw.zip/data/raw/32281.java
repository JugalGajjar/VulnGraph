import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserInputHandler {

    public void handleUserInput(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        String responseMessage = "Hello, " + userInput + "!";

        response.getWriter().write(responseMessage);
    }
}