import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        
        // Vulnerable code: directly outputting user input without proper validation or sanitization
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<h1>User Input:</h1>");
        out.println(userInput);
        out.println("</body>");
        out.println("</html>");
    }
}