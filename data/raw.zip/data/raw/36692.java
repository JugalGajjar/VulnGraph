import java.util.Locale;
import java.util.Objects;

public final class Money implements Comparable<Money> {
    private final long cents;
    private final Currency currency;

    public enum Currency {
        USD(1),
        EUR(1),
        GBP(1),
        JPY(0.01);

        private final double toMinor;

        Currency(double toMinor) {
            this.toMinor = toMinor;
        }
    }

    public Money(long cents, Currency currency) {
        if (currency == null) throw new IllegalArgumentException("Currency cannot be null");
        this.cents = cents;
        this.currency = currency;
    }

    public static Money of(double amount, Currency currency) {
        if (currency == null) throw new IllegalArgumentException("Currency cannot be null");
        long cents = Math.round(amount / currency.toMinor);
        return new Money(cents, currency);
    }

    public Money add(Money other) {
        checkCurrency(other);
        return new Money(this.cents + other.cents, currency);
    }

    public Money subtract(Money other) {
        checkCurrency(other);
        return new Money(this.cents - other.cents, currency);
    }

    public Money multiply(long factor) {
        return new Money(cents * factor, currency);
    }

    public Money divide(long divisor) {
        if (divisor == 0) throw new ArithmeticException("Divide by zero");
        return new Money(cents / divisor, currency);
    }

    public long getCents() {
        return cents;
    }

    public Currency getCurrency() {
        return currency;
    }

    private void checkCurrency(Money other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException("Currency mismatch");
        }
    }

    @Override
    public int compareTo(Money o) {
        checkCurrency(o);
        return Long.compare(this.cents, o.cents);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Money)) return false;
        Money money = (Money) o;
        return cents == money.cents && currency == money.currency;
    }

    @Override
    public int hashCode() {
        return Objects.hash(cents, currency);
    }

    @Override
    public String toString() {
        double major = cents * currency.toMinor;
        return String.format(Locale.US, "%.2f %s", major, currency);
    }
}