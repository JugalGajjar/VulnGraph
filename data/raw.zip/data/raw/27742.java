import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input
        String userInput = "<script>alert('XSS Vulnerability')</script>";

        // Improperly handling user input by directly outputting it to an HTML page
        String outputHtml = "<html><body>" + userInput + "</body></html>";

        try {
            // Writing the output HTML to a file
            FileWriter fileWriter = new FileWriter("output.html");
            fileWriter.write(outputHtml);
            fileWriter.close();

            System.out.println("Output HTML file generated successfully.");
        } catch (IOException e) {
            System.out.println("Error writing output HTML file: " + e.getMessage());
        }
    }
}