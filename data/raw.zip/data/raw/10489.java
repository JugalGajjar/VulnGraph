import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a file name: ");
        String fileName = scanner.nextLine();

        File file = new File("C:/data/" + fileName); // Vulnerable code
        if (file.exists()) {
            try {
                byte[] content = Files.readAllBytes(file.toPath());
                System.out.println(new String(content));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("File not found.");
        }

        scanner.close();
    }
}