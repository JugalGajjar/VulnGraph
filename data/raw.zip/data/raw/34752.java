import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the file name to read:");
        String fileName = scanner.nextLine();
        
        File file = new File("C:/data/" + fileName);
        
        try {
            byte[] fileContent = Files.readAllBytes(file.toPath());
            String content = new String(fileContent);
            System.out.println("File content: " + content);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        
        scanner.close();
    }
}