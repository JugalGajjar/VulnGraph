import java.io.*;

public class XSSVulnerability {
    public static void main(String[] args) {
        // Simulating user input from a form
        String userInput = "<script>alert('XSS Attack!')</script>";

        // Improperly handling user input by directly outputting it without proper encoding
        System.out.println("Welcome, " + userInput);
    }
}