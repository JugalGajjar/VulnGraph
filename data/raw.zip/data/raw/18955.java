import java.io.*;

public class CommandInjectionExample {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String command = br.readLine();

            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec(command);

            BufferedReader inputStreamReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = inputStreamReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}