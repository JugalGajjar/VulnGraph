import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input
        String userInput = "<script>alert('XSS Vulnerability!')</script>";

        // Improperly handling user input in a web application
        String output = "<p>Welcome, " + userInput + "</p>";

        System.out.println(output);
    }
}