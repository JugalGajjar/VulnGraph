import java.sql.*;

public class VulnerableCode {
    public static void main(String[] args) {
        String userInput = args[0]; // Assuming user input is passed as a command line argument

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "username", "password");
            Statement statement = connection.createStatement();
            
            String query = "SELECT * FROM users WHERE username='" + userInput + "'";
            ResultSet resultSet = statement.executeQuery(query);
            
            while(resultSet.next()) {
                System.out.println(resultSet.getString("username") + ": " + resultSet.getString("email"));
            }
            
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}