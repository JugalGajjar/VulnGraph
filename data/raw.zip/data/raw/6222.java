import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class SQLInjectionVulnerableApp {

    public static void main(String[] args) {
        try {
            // Establish database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "username", "password");
            
            // Get user input for username
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter username: ");
            String userInput = scanner.nextLine();
            
            // Construct SQL query with user input directly concatenated (Vulnerable to SQL Injection)
            String query = "SELECT * FROM users WHERE username='" + userInput + "'";
            
            // Execute the SQL query
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            // Process the results
            while (rs.next()) {
                System.out.println("User found: " + rs.getString("username"));
            }
            
            // Close resources
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}