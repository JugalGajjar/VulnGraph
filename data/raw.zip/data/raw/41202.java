package aurora;

import java.time.Instant;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * Encapsulates a single photon detected during an auroral event, including spatial,
 * spectral and temporal characteristics required for ionospheric tomography.
 *
 * @param <T> either "Kelvin" for black-body corrected temperatures or "Counts"
 *            for raw detector hits
 */
public final class AuroralPhoton<T> implements Comparable<AuroralPhoton<T>> {

    private static final double EARTH_RADIUS_KM = 6371.0088;

    private final Instant timestamp;
    private final double altitudeKm;
    private final double latitudeDeg;
    private final double longitudeDeg;
    private final double wavelengthNm;
    private final T intensity;

    public AuroralPhoton(Instant timestamp,
                         double altitudeKm,
                         double latitudeDeg,
                         double longitudeDeg,
                         double wavelengthNm,
                         T intensity) {
        if (timestamp == null) {
            throw new IllegalArgumentException("timestamp is required");
        }
        if (wavelengthNm <= 0 || wavelengthNm > 2000) {
            throw new IllegalArgumentException("wavelength must be 0-2000 nm");
        }
        if (!isValidCoordinate(latitudeDeg, longitudeDeg)) {
            throw new IllegalArgumentException("invalid lat/lon coordinates");
        }
        if (altitudeKm < -100 || altitudeKm > 2000) {
            throw new IllegalArgumentException("altitude outside reasonable range");
        }
        this.timestamp = timestamp;
        this.altitudeKm = altitudeKm;
        this.latitudeDeg = latitudeDeg;
        this.longitudeDeg = longitudeDeg;
        this.wavelengthNm = wavelengthNm;
        this.intensity = Objects.requireNonNull(intensity, "intensity cannot be null");
    }

    public Instant getTimestamp() { return timestamp; }

    public double getAltitudeKm() { return altitudeKm; }

    public double getLatitudeDeg() { return latitudeDeg; }

    public double getLongitudeDeg() { return longitudeDeg; }

    public double getWavelengthNm() { return wavelengthNm; }

    public T getIntensity() { return intensity; }

    /**
     * Computes the great-circle distance to another photon in kilometres.
     */
    public double distanceTo(AuroralPhoton<?> other) {
        Objects.requireNonNull(other);
        double lat1 = Math.toRadians(this.latitudeDeg);
        double lon1 = Math.toRadians(this.longitudeDeg);
        double lat2 = Math.toRadians(other.latitudeDeg);
        double lon2 = Math.toRadians(other.longitudeDeg);

        double deltaLat = lat2 - lat1;
        double deltaLon = lon2 - lon1;

        double a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
                   Math.cos(lat1) * Math.cos(lat2) *
                   Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS_KM * c;
    }

    /**
     * Estimates the photon energy in electron-volts using E = hc/?.
     */
    public double energyEV() {
        return 1239.8 / wavelengthNm;
    }

    /**
     * Returns true if the photon is within the green OI 557.7 nm emission line band.
     */
    public boolean isGreenOI5577() {
        return Math.abs(wavelengthNm - 557.7) <= 0.1;
    }

    @Override
    public int compareTo(AuroralPhoton<T> o) {
        int cmp = timestamp.compareTo(o.timestamp);
        return cmp != 0 ? cmp : Integer.compare(this.hashCode(), o.hashCode());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof AuroralPhoton)) return false;
        AuroralPhoton<?> that = (AuroralPhoton<?>) obj;
        return Double.compare(that.altitudeKm, altitudeKm) == 0 &&
               Double.compare(that.latitudeDeg, latitudeDeg) == 0 &&
               Double.compare(that.longitudeDeg, longitudeDeg) == 0 &&
               Double.compare(that.wavelengthNm, wavelengthNm) == 0 &&
               timestamp.equals(that.timestamp) &&
               intensity.equals(that.intensity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(timestamp, altitudeKm, latitudeDeg, longitudeDeg,
                            wavelengthNm, intensity);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", AuroralPhoton.class.getSimpleName() + "[", "]")
                .add("time=" + timestamp)
                .add("alt=" + altitudeKm + " km")
                .add("lat=" + latitudeDeg + "°")
                .add("lon=" + longitudeDeg + "°")
                .add("?=" + wavelengthNm + " nm")
                .add("intensity=" + intensity)
                .toString();
    }

    private static boolean isValidCoordinate(double lat, double lon) {
        return (lat >= -90 && lat <= 90) && (lon >= -180 && lon <= 180);
    }
}