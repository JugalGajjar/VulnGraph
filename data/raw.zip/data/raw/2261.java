import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input
        String userInput = "<script>alert('XSS attack!')</script>";

        // Improperly handling user input by directly outputting it to the webpage
        System.out.println("Welcome, " + userInput);
    }
}