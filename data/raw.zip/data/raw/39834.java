import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

public class IdGenerator {
    private static final AtomicLong COUNTER = new AtomicLong(0);
    private final String prefix;

    public IdGenerator(String prefix) {
        this.prefix = Objects.requireNonNull(prefix, "prefix must not be null");
    }

    public String nextId() {
        return prefix + COUNTER.incrementAndGet();
    }
}