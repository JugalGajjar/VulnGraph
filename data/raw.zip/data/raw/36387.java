public class FactorialCalculator {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java FactorialCalculator <non-negative integer>");
            System.exit(1);
        }
        try {
            int n = Integer.parseInt(args[0]);
            if (n < 0) {
                throw new IllegalArgumentException("Number must be non-negative");
            }
            System.out.println(factorial(n));
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format");
            System.exit(2);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.exit(3);
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            System.exit(4);
        }
    }

    private static java.math.BigInteger factorial(int n) {
        java.math.BigInteger result = java.math.BigInteger.ONE;
        for (int i = 2; i <= n; i++) {
            result = result.multiply(java.math.BigInteger.valueOf(i));
        }
        return result;
    }
}