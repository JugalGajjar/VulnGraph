import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.nio.file.Paths;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = "../../../../../etc/passwd";
        String directory = "/var/www/files/";

        String fullPath = directory + userInput;
        
        try {
            File file = new File(fullPath);
            if (file.exists()) {
                byte[] content = Files.readAllBytes(Paths.get(fullPath));
                System.out.println(new String(content));
            } else {
                System.out.println("File not found");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}