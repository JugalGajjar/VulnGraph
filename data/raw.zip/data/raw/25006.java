import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalVulnerability {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter file name: ");
        String fileName = scanner.nextLine();
        
        File file = new File("/path/to/files/" + fileName);
        
        try {
            if(file.exists()) {
                System.out.println("File exists at path: " + file.getCanonicalPath());
            } else {
                System.out.println("File does not exist.");
            }
        } catch (IOException e) {
            System.out.println("Error accessing file.");
        }
    }
}