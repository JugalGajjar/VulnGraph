package util;

import java.util.Objects;

public final class StringUtil {

    private StringUtil() {
        throw new AssertionError("No StringUtil instances for you!");
    }

    public static boolean isNullOrBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static boolean isNullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }

    public static String requireNonBlank(String s, String message) {
        if (isNullOrBlank(s)) {
            throw new IllegalArgumentException(message);
        }
        return s.trim();
    }

    public static String truncate(String s, int maxLen) {
        if (maxLen < 0) {
            throw new IllegalArgumentException("maxLen must be non-negative");
        }
        if (isNullOrEmpty(s) || s.length() <= maxLen) {
            return s;
        }
        return s.substring(0, maxLen);
    }

    public static String sanitizeFilename(String filename) {
        Objects.requireNonNull(filename, "filename");
        return filename.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}