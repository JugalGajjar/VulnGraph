package com.acoustic.beampattern;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;
import java.util.StringJoiner;

/**
 * Encodes and decodes underwater acoustic beam-pattern telemetry into a
 * 64-character Base64-like stream with embedded parity, checksum and
 * metadata compression.
 *
 * Designed for real-time buoy-to-shore data-links with <1 kB payloads.
 */
public final class AcousticBeamPacketCodec {

    private static final int MAX_PACKET_BYTES = 1021;
    private static final int MIN_PACKET_BYTES = 9;
    private static final char[] ALPHABET =
            ("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
           + "abcdefghijklmnopqrstuvwxyz"
           + "0123456789+/").toCharArray();
    private static final int[] REVERSE = new int[128];
    static {
        Arrays.fill(REVERSE, -1);
        for (int i = 0; i < ALPHABET.length; i++) {
            REVERSE[ALPHABET[i]] = i;
        }
    }

    private AcousticBeamPacketCodec() { }

    /**
     * Encodes raw beam-pattern data into a packet payload.
     *
     * Packet format (bytes):
     * [0]   version & compression flags
     * [1-2] sequence number
     * [3-6] timestamp (Unix seconds, lower 32 bits)
     * [7-n] compressed beam data
     * [n+1] 3-bit row-major parity + 5-bit checksum
     *
     * Returns URL-safe, linebreak-free ASCII.
     *
     * @param data raw 16-bit angle-gain samples
     * @param seq sequence number (065535)
     * @param ts Unix timestamp
     * @return encoded packet
     * @throws IllegalArgumentException for null or oversized data
     */
    public static String encode(short[] data, int seq, long ts) {
        Objects.requireNonNull(data, "data");
        Objects.checkFromIndexSize(0, data.length * 2, MAX_PACKET_BYTES - 9);
        if (seq < 0 || seq > 0xFFFF) {
            throw new IllegalArgumentException("seq out of range");
        }

        int len = data.length;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);
        try {
            dos.writeByte( (1 << 5)                           // version 1, compression flag
                         | (len > 255 ? 1 : 0) );            // flag large array
            dos.writeShort(seq);
            dos.writeInt((int) ts);

            for (short s : data) {
                dos.write(s & 0xFF);
                dos.write((s >>> 8) & 0xFF);
            }

            byte[] payload = baos.toByteArray();
            int checksum = checksum(payload, 0, payload.length - 1);
            int parity = parity(payload);
            payload[payload.length - 1] = (byte) ((parity << 5) | checksum);

            return base64url(payload);
        } catch (IOException impossible) {
            throw new UncheckedIOException(impossible);
        }
    }

    /**
     * Decodes a packet produced by {@link #encode(short[], int, long)}.
     *
     * @param packet URL-safe, linebreak-free ASCII
     * @return decoded structure
     * @throws IllegalArgumentException on malformed input
     */
    public static BeamPacket decode(String packet) {
        Objects.requireNonNull(packet, "packet");
        byte[] bytes = decodeBase64url(packet);
        if (bytes == null || bytes.length < MIN_PACKET_BYTES) {
            throw new IllegalArgumentException("packet too small");
        }

        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(bytes));
        try {
            int flags = dis.readUnsignedByte();
            int version = (flags >>> 5) & 0x07;
            if (version != 1) {
                throw new IllegalArgumentException("unsupported version");
            }

            int seq = dis.readUnsignedShort();
            long ts = dis.readInt() & 0xFFFFFFFFL;

            int payloadOffset = 7;
            int payloadLength = bytes.length - 1 - payloadOffset;
            if (payloadLength < 0 || (payloadLength & 1) != 0) {
                throw new IllegalArgumentException("invalid payload length");
            }

            short[] data = new short[payloadLength / 2];
            for (int i = 0; i < data.length; i++) {
                int lo = dis.readUnsignedByte();
                int hi = dis.readUnsignedByte();
                data[i] = (short) (lo | (hi << 8));
            }

            int expected = bytes[bytes.length - 1] & 0xFF;
            int actual = checksum(bytes, 0, bytes.length - 2);
            actual |= parity(bytes) << 5;
            if ((actual & 0xFF) != expected) {
                throw new IllegalArgumentException("checksum/parity mismatch");
            }

            return new BeamPacket(data, seq, ts);
        } catch (IOException impossible) {
            throw new UncheckedIOException(impossible);
        }
    }

    /* ----------- internal utilities ----------- */

    private static int checksum(byte[] b, int off, int end) {
        int sum = 0;
        for (int i = off; i <= end; i++) {
            // Fletcher-16 on bytes
            sum = (sum + (b[i] & 0xFF)) % 31;
        }
        return sum;
    }

    private static int parity(byte[] b) {
        int p = 0;
        for (byte value : b) {
            p ^= Integer.bitCount(value & 0xFF);
        }
        return p & 0x07;
    }

    private static String base64url(byte[] src) {
        int len = (src.length + 2) / 3 * 4;
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < src.length; ) {
            int a = (i < src.length) ? (src[i++] & 0xFF) : 0;
            int b = (i < src.length) ? (src[i++] & 0xFF) : 0;
            int c = (i < src.length) ? (src[i++] & 0xFF) : 0;

            sb.append(ALPHABET[(a >>> 2) & 0x3F]);
            sb.append(ALPHABET[((a << 4) | (b >>> 4)) & 0x3F]);
            sb.append(ALPHABET[((b << 2) | (c >>> 6)) & 0x3F]);
            sb.append(ALPHABET[c & 0x3F]);
        }
        // remove padding; URL-safe
        while (sb.length() > 0 && sb.charAt(sb.length() - 1) == '=') {
            sb.setLength(sb.length() - 1);
        }
        return sb.toString();
    }

    private static byte[] decodeBase64url(String src) {
        String s = src.replace('-', '+').replace('_', '/');
        int pads = 4 - (s.length() % 4);
        if (pads == 4) pads = 0;
        for (int i = 0; i < pads; i++) {
            s += '=';
        }
        try {
            int bytes = (s.length() * 6) >>> 3;
            byte[] dst = new byte[bytes];
            int idx = 0;
            int accum = 0;
            int bits = 0;
            for (char c : s.toCharArray()) {
                int v = (c > 127) ? -1 : REVERSE[c];
                if (v < 0) throw new IllegalArgumentException("illegal char");
                accum = (accum << 6) | v;
                bits += 6;
                if (bits >= 8) {
                    dst[idx++] = (byte) (accum >>> (bits - 8));
                    bits -= 8;
                }
            }
            return dst;
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /* ----------- data container ----------- */

    public record BeamPacket(short[] data, int sequence, long timestamp) {
        @Override
        public String toString() {
            return new StringJoiner(", ", BeamPacket.class.getSimpleName() + "[", "]")
                    .add("samples=" + data.length)
                    .add("seq=" + sequence)
                    .add("ts=" + timestamp).toString();
        }
    }
}