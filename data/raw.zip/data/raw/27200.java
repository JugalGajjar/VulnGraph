import java.io.IOException;
import java.io.PrintWriter;

public class XSSVulnerableCode {

    public static void main(String[] args) throws IOException {
        String userInput = "<script>alert('XSS Attack!');</script>";
        
        // Improperly handling user input by directly printing it to the response
        PrintWriter out = new PrintWriter("output.html");
        out.println("<html>");
        out.println("<body>");
        out.println("User Input: " + userInput);
        out.println("</body>");
        out.println("</html>");
        
        out.close();
    }
}