import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a hostname to ping: ");
        String hostname = reader.readLine();

        // Vulnerable code - directly concatenating user input into the command
        String command = "ping -c 3 " + hostname;

        Process process = Runtime.getRuntime().exec(command);

        BufferedReader inputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = inputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}