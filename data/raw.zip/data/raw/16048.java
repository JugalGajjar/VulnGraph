import java.io.*;

public class InsecureDeserializationExample {

    public static void main(String[] args) {
        try {
            String userInput = "HelloWorld"; // User input - this could be data from an untrusted source

            // Serialize the user input object
            byte[] serializedInput = serializeObject(userInput);

            // Deserialize the object without proper validation
            Object deserializedObject = deserializeObject(serializedInput);

            System.out.println("Deserialized object: " + deserializedObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static byte[] serializeObject(Object obj) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(obj);
        return bos.toByteArray();
    }

    private static Object deserializeObject(byte[] data) throws IOException, ClassNotFoundException {
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois = new ObjectInputStream(bis);
        return ois.readObject();
    }
}