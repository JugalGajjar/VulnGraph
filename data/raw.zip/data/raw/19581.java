import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String fileName = args[0]; // User input for file name

        try {
            File file = new File("/path/to/files/" + fileName); // Vulnerable code that concatenates user input with base path
            FileInputStream fis = new FileInputStream(file);
            // Read file content and do something with it
            fis.close();
        } catch (IOException e) {
            System.out.println("Error accessing file: " + e.getMessage());
        }
    }
}