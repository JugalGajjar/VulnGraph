package util;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.stream.Collectors;

public final class HttpClient {

    private HttpClient() {}

    public static String get(String url) throws IOException {
        return request("GET", url, null, null);
    }

    public static String post(String url, String body) throws IOException {
        return request("POST", url, body, Map.of("Content-Type", "application/json"));
    }

    public static String request(String method, String url, String body, Map<String, String> headers) throws IOException {
        if (method == null || method.trim().isEmpty()) throw new IllegalArgumentException("HTTP method is required");
        if (url == null || url.trim().isEmpty()) throw new IllegalArgumentException("URL is required");

        HttpsURLConnection conn = null;
        try {
            conn = (HttpsURLConnection) new URL(url).openConnection();
            conn.setRequestMethod(method.toUpperCase());

            if (headers != null) {
                headers.forEach(conn::setRequestProperty);
            }

            if (body != null && ("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method))) {
                conn.setDoOutput(true);
                conn.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
            }

            int status = conn.getResponseCode();
            if (status >= 400) {
                String error = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))
                        .lines().collect(Collectors.joining("\n"));
                throw new IOException("HTTP " + status + ": " + error);
            }

            return new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))
                    .lines().collect(Collectors.joining("\n"));
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}