import java.util.Scanner;

public class BufferOverflowVulnerability {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        
        // Vulnerable code - allocating fixed size buffer for storing user input
        byte[] buffer = new byte[10];
        
        // Copying user input into the buffer without proper bounds checking
        System.arraycopy(name.getBytes(), 0, buffer, 0, name.length());
        
        System.out.println("Welcome, " + new String(buffer));
    }
}