import java.io.IOException;
import java.util.Scanner;

public class CommandInjectionExample {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a file name: ");
        String fileName = scanner.next();
        
        // Vulnerable code that allows for command injection
        Process process = Runtime.getRuntime().exec("ls " + fileName);
        
        // Read the output of the command
        Scanner processScanner = new Scanner(process.getInputStream());
        while (processScanner.hasNextLine()) {
            System.out.println(processScanner.nextLine());
        }
        
        scanner.close();
    }
}