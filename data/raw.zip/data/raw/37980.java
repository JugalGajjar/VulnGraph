package util;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;

public final class FileUtil {

    private FileUtil() {
        throw new AssertionError("No instances");
    }

    public static String readAllUtf8(Path path) {
        Objects.requireNonNull(path, "path");
        try {
            return Files.readString(path);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static void writeUtf8(Path path, String text) {
        Objects.requireNonNull(path, "path");
        Objects.requireNonNull(text, "text");
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, text);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}