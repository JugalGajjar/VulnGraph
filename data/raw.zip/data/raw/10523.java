import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerability {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a file name: ");
        String fileName = scanner.nextLine();
        
        File file = new File("/path/to/directory/" + fileName);
        
        try {
            byte[] fileData = Files.readAllBytes(file.toPath());
            System.out.println(new String(fileData));
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        
        scanner.close();
    }
}