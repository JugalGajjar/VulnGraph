import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Enter a command to execute: ");
            String userInput = reader.readLine();
            
            // Vulnerable code: User input is directly passed to the command line for execution
            Process process = Runtime.getRuntime().exec("ping " + userInput);
            
            BufferedReader inputStreamReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            
            while ((line = inputStreamReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}