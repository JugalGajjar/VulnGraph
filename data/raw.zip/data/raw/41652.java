package astrobotany;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Astrobotanist mission support system that uses the Visitor pattern to
 * analyze plant responses to micro-gravity cosmic radiation exposure.
 *
 * All code is self-contained in this single file.
 */
public class AstrobotanyRadiationAnalyzer {

    /* === DOMAIN MODEL === */

    public interface SpacePlant {
        void accept(SpacePlantVisitor visitor);
    }

    public abstract static class AbstractSpacePlant implements SpacePlant {
        protected final String cultivar;
        protected final RadiationExposure exposure;

        protected AbstractSpacePlant(String cultivar, RadiationExposure exposure) {
            this.cultivar = Objects.requireNonNull(cultivar);
            this.exposure = Objects.requireNonNull(exposure);
        }

        public String getCultivar() { return cultivar; }
        public RadiationExposure getExposure() { return exposure; }
    }

    public static class Tomato extends AbstractSpacePlant {
        public Tomato(String cultivar, RadiationExposure exposure) { super(cultivar, exposure); }
    }

    public static class Wheat extends AbstractSpacePlant {
        public Wheat(String cultivar, RadiationExposure exposure) { super(cultivar, exposure); }
    }

    public static class Lettuce extends AbstractSpacePlant {
        public Lettuce(String cultivar, RadiationExposure exposure) { super(cultivar, exposure); }
    }

    /* === RADIATION DOMAIN === */

    public static final class RadiationExposure {
        private final double sievertDosage;
        private final LocalDate exposureDate;
        private final Set<IonType> ions;

        public enum IonType { ALPHA, BETA, GAMMA, COSMIC_PROTON }

        public RadiationExposure(double sievertDosage, LocalDate exposureDate, Set<IonType> ions) {
            if (sievertDosage < 0) throw new IllegalArgumentException("Dosage must be non-negative");
            this.sievertDosage = sievertDosage;
            this.exposureDate = Objects.requireNonNull(exposureDate);
            this.ions = Collections.unmodifiableSet(new HashSet<>(ions));
        }

        public double getSievertDosage() { return sievertDosage; }
        public LocalDate getExposureDate() { return exposureDate; }
        public Set<IonType> getIons() { return ions; }
    }

    /* === VISITOR === */

    public interface SpacePlantVisitor<R> {
        R visitTomato(Tomato tomato);
        R visitWheat(Wheat wheat);
        R visitLettuce(Lettuce lettuce);
    }

    public static final class ViabilityPredictor implements SpacePlantVisitor<PredictedViability> {
        @Override
        public PredictedViability visitTomato(Tomato tomato) {
            return compute(tomato, 0.92, 0.75);
        }

        @Override
        public PredictedViability visitWheat(Wheat wheat) {
            return compute(wheat, 0.85, 0.60);
        }

        @Override
        public PredictedViability visitLettuce(Lettuce lettuce) {
            return compute(lettuce, 0.88, 0.70);
        }

        private PredictedViability compute(AbstractSpacePlant plant,
                                         double radiationToleranceFactor,
                                         double growthPenalty) {
            double dose = plant.getExposure().getSievertDosage();
            double severity = dose * radiationToleranceFactor * growthPenalty;
            boolean viable = severity < 1.5;
            return new PredictedViability(viable, severity);
        }
    }

    public static final class IonizationEffectMapper implements SpacePlantVisitor<Map<RadiationExposure.IonType, Double>> {
        @Override
        public Map<RadiationExposure.IonType, Double> visitTomato(Tomato tomato) {
            return map(tomato, Map.of(
                    RadiationExposure.IonType.ALPHA, 0.95,
                    RadiationExposure.IonType.BETA, 0.87,
                    RadiationExposure.IonType.GAMMA, 0.92,
                    RadiationExposure.IonType.COSMIC_PROTON, 0.90
            ));
        }

        @Override
        public Map<RadiationExposure.IonType, Double> visitWheat(Wheat wheat) {
            return map(wheat, Map.of(
                    RadiationExposure.IonType.ALPHA, 0.88,
                    RadiationExposure.IonType.BETA, 0.80,
                    RadiationExposure.IonType.GAMMA, 0.90,
                    RadiationExposure.IonType.COSMIC_PROTON, 0.92
            ));
        }

        @Override
        public Map<RadiationExposure.IonType, Double> visitLettuce(Lettuce lettuce) {
            return map(lettuce, Map.of(
                    RadiationExposure.IonType.ALPHA, 0.90,
                    RadiationExposure.IonType.BETA, 0.85,
                    RadiationExposure.IonType.GAMMA, 0.88,
                    RadiationExposure.IonType.COSMIC_PROTON, 0.86
            ));
        }

        private Map<RadiationExposure.IonType, Double> map(AbstractSpacePlant plant,
                                                             Map<RadiationExposure.IonType, Double> factors) {
            double dose = plant.getExposure().getSievertDosage();
            return plant.getExposure().getIons().stream()
                    .collect(Collectors.toMap(
                            ion -> ion,
                            ion -> dose * factors.getOrDefault(ion, 1.0)));
        }
    }

    /* === VALUE OBJECTS === */

    public static final class PredictedViability {
        private final boolean viable;
        private final double severityIndex;

        public PredictedViability(boolean viable, double severityIndex) {
            this.viable = viable;
            this.severityIndex = severityIndex;
        }

        public boolean isViable() { return viable; }
        public double getSeverityIndex() { return severityIndex; }
    }

    /* === FACADE === */

    public static class AnalyzerFacade {
        private final ViabilityPredictor predictor = new ViabilityPredictor();
        private final IonizationEffectMapper mapper = new IonizationEffectMapper();

        public MissionReport analyzeMission(List<SpacePlant> missionPlants) {
            if (missionPlants == null) throw new IllegalArgumentException("plants list must not be null");
            Map<String, PredictedViability> viabilities = new HashMap<>();
            Map<String, Map<RadiationExposure.IonType, Double>> effectMap = new HashMap<>();

            for (SpacePlant plant : missionPlants) {
                AbstractSpacePlant ap = (AbstractSpacePlant) plant; // safe cast as per domain
                viabilities.put(ap.getCultivar(), ap.accept(predictor));
                effectMap.put(ap.getCultivar(), ap.accept(mapper));
            }
            return new MissionReport(viabilities, effectMap);
        }
    }

    public static final class MissionReport {
        private final Map<String, PredictedViability> viabilities;
        private final Map<String, Map<RadiationExposure.IonType, Double>> effectMap;

        public MissionReport(Map<String, PredictedViability> viabilities,
                             Map<String, Map<RadiationExposure.IonType, Double>> effectMap) {
            this.viabilities = viabilities;
            this.effectMap = effectMap;
        }

        public Map<String, PredictedViability> getViabilities() { return viabilities; }
        public Map<String, Map<RadiationExposure.IonType, Double>> getEffectMap() { return effectMap; }
    }

    /* === TESTING ENTRY === */

    public static void main(String[] args) {
        LocalDate now = LocalDate.now();
        List<SpacePlant> crops = List.of(
                new Tomato("Red Dwarf", new RadiationExposure(0.3, now, EnumSet.of(RadiationExposure.IonType.GAMMA))),
                new Wheat("Space Norin", new RadiationExposure(0.6, now, EnumSet.allOf(RadiationExposure.IonType.class)))
        );
        MissionReport report = new AnalyzerFacade().analyzeMission(crops);
        report.getViabilities().forEach((c, v) ->
                System.out.printf("%s viability: %s (severity=%.2f)%n", c, v.isViable(), v.getSeverityIndex()));
    }
}