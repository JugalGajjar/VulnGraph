import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerability {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter file name: ");
        String fileName = scanner.nextLine();
        
        File file = new File(fileName);
        
        try {
            if (file.exists()) {
                byte[] fileContent = Files.readAllBytes(file.toPath());
                System.out.println(new String(fileContent));
            } else {
                System.out.println("File not found");
            }
        } catch (IOException e) {
            System.out.println("Error reading file");
        }
        
        scanner.close();
    }
}