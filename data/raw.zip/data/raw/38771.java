import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import java.util.Objects;

public final class Memoizer<K, V> {

    private final ConcurrentHashMap<K, V> cache = new ConcurrentHashMap<>();

    public V memoize(K key, Supplier<V> supplier) {
        Objects.requireNonNull(key, "key must not be null");
        Objects.requireNonNull(supplier, "supplier must not be null");
        return cache.computeIfAbsent(key, k -> supplier.get());
    }

    public void clear() {
        cache.clear();
    }

    public long size() {
        return cache.mappingCount();
    }

    public static void main(String[] args) {
        Memoizer<String, Long> m = new Memoizer<>();
        Supplier<Long> s = System::currentTimeMillis;
        System.out.println(m.memoize("now", s));
        System.out.println(m.memoize("now", s));
        System.out.println("Cache size: " + m.size());
        m.clear();
        System.out.println("Cache size after clear: " + m.size());
    }
}