import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter file name: ");
        String fileName = scanner.nextLine();

        File file = new File("/path/to/files/" + fileName);

        try {
            byte[] fileContent = Files.readAllBytes(file.toPath());
            System.out.println("File content: " + new String(fileContent));
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}