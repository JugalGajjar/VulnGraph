import java.util.Scanner;

public class NumberValidator {
    public static boolean isValidNumber(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        String input = scanner.nextLine();
        if (isValidNumber(input)) {
            System.out.println("Valid number");
        } else {
            System.out.println("Invalid number");
        }
    }
}