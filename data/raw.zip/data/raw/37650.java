import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateParser {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static LocalDate parseDate(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) {
            throw new IllegalArgumentException("Date string cannot be empty");
        }

        try {
            return LocalDate.parse(dateStr, DATE_FORMAT);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date format: " + dateStr, e);
        }
    }

    public static void main(String[] args) {
        System.out.println(parseDate("2022-01-01")); // 2022-01-01
        try {
            System.out.println(parseDate("invalid-date")); // IllegalArgumentException
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage()); // Invalid date format: invalid-date
        }
    }
}