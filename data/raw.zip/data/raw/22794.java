import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class XSSVulnerableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        
        // Improperly handling user input by directly outputting it to the response
        response.getWriter().println("<p>User Input: " + userInput + "</p>");
    }
}