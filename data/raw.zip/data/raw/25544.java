import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String fileName = args[0]; // User input for file name
        readFile(fileName);
    }

    public static void readFile(String fileName) {
        try {
            File file = new File("/path/to/files/" + fileName); // Vulnerable code: User input is directly concatenated to the file path
            FileInputStream fis = new FileInputStream(file);
            int content;
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }
            fis.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}