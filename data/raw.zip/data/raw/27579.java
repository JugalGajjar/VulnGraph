import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        
        // Vulnerability: User input is directly outputted to the response without proper sanitization
        String output = "<html><body>User input: " + userInput + "</body></html>";
        
        PrintWriter out = response.getWriter();
        out.println(output);
    }
}