import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VulnerableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        String output = "Welcome, " + userInput + "!";

        response.getWriter().write("<html><body>");
        response.getWriter().write("<h1>" + output + "</h1>");
        response.getWriter().write("</body></html>");
    }
}