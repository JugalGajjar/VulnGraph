import java.io.*;

public class CommandInjectionExample {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String command = reader.readLine();

            Process process = Runtime.getRuntime().exec("ping " + command);

            BufferedReader inputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String inputLine;
            while ((inputLine = inputReader.readLine()) != null) {
                System.out.println(inputLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}