import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a directory name to list files: ");
        String directoryName = reader.readLine();
        
        // Vulnerability: User input is directly concatenated into the command without proper validation or sanitization
        String command = "ls " + directoryName;
        
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader processOutputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        System.out.println("Files in directory " + directoryName + ":");
        while ((line = processOutputReader.readLine()) != null) {
            System.out.println(line);
        }
        
    }
}