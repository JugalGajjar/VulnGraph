import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerability {
    public static void main(String[] args) {
        try {
            // Taking user input for a command to execute
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String userInput = br.readLine();

            // Executing the user input command using Runtime.getRuntime().exec()
            Process process = Runtime.getRuntime().exec("ping " + userInput);

            // Reading and printing the output of the command execution
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}