import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

public final class TinyHttpClient {
    private static final Duration DEFAULT_TIMEOUT = Duration.ofSeconds(10);
    private final HttpClient client;

    private TinyHttpClient(HttpClient client) {
        this.client = Objects.requireNonNull(client);
    }

    public static TinyHttpClient create() {
        HttpClient client = HttpClient.newBuilder()
                                     .connectTimeout(DEFAULT_TIMEOUT)
                                     .build();
        return new TinyHttpClient(client);
    }

    public String get(String url) throws IOException, InterruptedException {
        requireValidUrl(url);
        HttpRequest request = HttpRequest.newBuilder()
                                       .uri(URI.create(url))
                                       .timeout(DEFAULT_TIMEOUT)
                                       .GET()
                                       .build();
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public CompletableFuture<String> getAsync(String url) {
        requireValidUrl(url);
        HttpRequest request = HttpRequest.newBuilder()
                                       .uri(URI.create(url))
                                       .timeout(DEFAULT_TIMEOUT)
                                       .GET()
                                       .build();
        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                     .thenApply(HttpResponse::body);
    }

    private static void requireValidUrl(String url) {
        if (url == null || !url.startsWith("http")) {
            throw new IllegalArgumentException("Invalid URL: " + url);
        }
    }
}