import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        File file = new File("C:\\data\\" + fileName); // Vulnerability: User input is directly concatenated to the file path

        try {
            byte[] fileContents = Files.readAllBytes(file.toPath());
            System.out.println("File contents: " + new String(fileContents));
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}