import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter file name to read: ");
        String fileName = scanner.nextLine();
        
        try {
            File file = new File("C:\\data\\" + fileName); // Vulnerable code, user input directly concatenated to the file path
            FileInputStream fis = new FileInputStream(file);
            
            int content;
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }
            
            fis.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        
        scanner.close();
    }

}