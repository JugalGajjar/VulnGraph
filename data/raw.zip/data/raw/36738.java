import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

public class WordCounter {

    private static final Pattern WORD_PATTERN = Pattern.compile("\\b\\w+\\b");

    /**
     * Counts the number of words in the given text.
     *
     * @param text the text to analyze, must not be null
     * @return the word count
     */
    public static int countWords(String text) {
        if (text == null) {
            throw new IllegalArgumentException("Input text cannot be null");
        }
        return (int) WORD_PATTERN.matcher(text).results().count();
    }

    /**
     * Reads the entire content of a file as a UTF-8 string.
     *
     * @param path the path to the file, must not be null
     * @return file content
     * @throws IOException if an I/O error occurs reading the file
     */
    public static String readFile(Path path) throws IOException {
        if (path == null) {
            throw new IllegalArgumentException("File path cannot be null");
        }
        return Files.readString(path);
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java WordCounter <path-to-text-file>");
            System.exit(1);
        }

        Path filePath = Paths.get(args[0]);

        try {
            String content = readFile(filePath);
            int wordCount = countWords(content);
            System.out.println("Word count: " + wordCount);
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid argument: " + e.getMessage());
            System.exit(2);
        } catch (IOException e) {
            System.err.println("Failed to read file '" + filePath + "': " + e.getMessage());
            System.exit(3);
        }
    }
}