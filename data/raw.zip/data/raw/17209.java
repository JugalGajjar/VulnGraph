import java.io.*;

public class XSSVulnerabilityExample {
    public static void main(String[] args) {
        // Simulating user input
        String userInput = "<script>alert('XSS Vulnerability')</script>";

        // Displaying user input on a web page without proper sanitization
        System.out.println("Welcome, " + userInput);
    }
}