import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter your name: ");
        
        try {
            String userInput = reader.readLine();
            System.out.println("Hello, " + userInput + "!"); // Vulnerable code
        } catch (IOException e) {
            System.err.println("Error reading input");
        }
    }
}