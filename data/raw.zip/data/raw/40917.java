/*
 * QuantumStateDifferentialAnalyzerCache.java
 *
 * Implements a time-decaying quantum state differential analyzer cache that stores
 * probabilistic wave-function gradients with phase-aware eviction and collapse-triggered
 * invalidation.  Used in real-time adaptive quantum control systems.
 *
 * This class caches computed partial derivatives of the quantum state vector
 * with respect to Hamiltonian parameters, retaining them only while their phase
 * coherence is statistically likely under the current noise profile.
 *
 * Thread-safe, lock-free reads with probabilistic expiration based on a
 * two-level LRULRFU hybrid weighted by decoherence probability.
 */
package quantum.control;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ThreadLocalRandom;

public final class QuantumStateDifferentialAnalyzerCache {

    // Domain object describing a quantum state's gradient slice
    public static final class GradientSlice {
        public final double[] real;     // ?Re(|??)/??
        public final double[] imag;     // ?Im(|??)/??
        public final double coherence;    // 1  P(decoherence)
        public final long   timestamp;    // creation monotonic nanos
        public final int    hash;

        GradientSlice(double[] real, double[] imag, double coherence) {
            this.real = real.clone();
            this.imag = imag.clone();
            this.coherence = coherence;
            this.timestamp = System.nanoTime();
            this.hash = computeHash();
        }

        private int computeHash() {
            int h = 31 * Double.hashCode(coherence);
            for (double v : real) h = h * 31 + Double.hashCode(v);
            for (double v : imag) h = h * 31 + Double.hashCode(v);
            return h;
        }

        @Override
        public int hashCode() { return hash; }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof GradientSlice gs)) return false;
            if (gs.coherence != coherence) return false;
            for (int i = 0; i < real.length; i++) if (real[i] != gs.real[i]) return false;
            for (int i = 0; i < imag.length; i++) if (imag[i] != gs.imag[i]) return false;
            return true;
        }
    }

    // Cache entry with decaying weight
    private static final class CacheEntry {
        final GradientSlice slice;
        final AtomicLong hits  = new AtomicLong(1);
        final AtomicLong noise = new AtomicLong(Double.doubleToLongBits(ThreadLocalRandom.current().nextDouble()));

        CacheEntry(GradientSlice slice) {
            this.slice = slice;
        }
    }

    private final ConcurrentHashMap<HamiltonianKey, CacheEntry> store;
    private final int capacity;
    private final double decayRate;

    public QuantumStateDifferentialAnalyzerCache(int capacity, double decayRate) {
        if (capacity <= 0 || decayRate <= 0 || decayRate > 1)
            throw new IllegalArgumentException("Invalid cache parameters");
        this.capacity = capacity;
        this.decayRate = decayRate;
        this.store = new ConcurrentHashMap<>(capacity * 2);
    }

    public GradientSlice computeIfAbsent(int[] controlWord,
                                       double temperature,
                                       java.util.function.Supplier<GradientSlice> supplier) {
        HamiltonianKey key = new HamiltonianKey(controlWord, temperature);
        CacheEntry entry = store.computeIfAbsent(key, k -> new CacheEntry(supplier.get()));
        entry.hits.incrementAndGet();

        // Probabilistic eviction on collision or decay threshold
        evictIfNeeded();
        return entry.slice;
    }

    private void evictIfNeeded() {
        if (store.size() <= capacity) return;
        store.entrySet()
              .stream()
              .min((a, b) -> Double.compare(
                      a.getValue().slice.coherence * fastDecay(a.getValue()),
                      b.getValue().slice.coherence * fastDecay(b.getValue())))
              .ifPresent(e -> store.remove(e.getKey(), e.getValue()));
    }

    private double fastDecay(CacheEntry e) {
        return Math.pow(decayRate, (System.nanoTime() - e.slice.timestamp) / 1_000_000_000.0);
    }

    // Key combining control word and bath temperature
    private static final class HamiltonianKey {
        private final int[] controlWord;
        private final double temperature;
        private final int hash;

        HamiltonianKey(int[] controlWord, double temperature) {
            this.controlWord = controlWord.clone();
            this.temperature = temperature;
            this.hash = computeHash();
        }

        private int computeHash() {
            int h = 17;
            for (int b : controlWord) h = h * 31 + b;
            long t = Double.doubleToLongBits(temperature);
            h = h * 31 + (int) (t ^ (t >>> 32));
            return h;
        }

        @Override
        public int hashCode() { return hash; }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof HamiltonianKey hk)) return false;
            if (hk.temperature != temperature) return false;
            return java.util.Arrays.equals(controlWord, hk.controlWord);
        }
    }
}