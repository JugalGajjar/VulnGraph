import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter your name: ");
        String userInput = br.readLine();
        
        System.out.println("Hello, " + userInput + "! Welcome to our website!");
    }
}