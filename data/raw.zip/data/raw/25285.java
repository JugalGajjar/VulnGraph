import java.io.File;
import java.util.Scanner;

public class PathTraversalExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter file name:");
        String fileName = scanner.nextLine();
        
        File file = new File("/path/to/directory/" + fileName);
        
        if (file.exists()) {
            System.out.println("File exists!");
        } else {
            System.out.println("File does not exist.");
        }
    }
}