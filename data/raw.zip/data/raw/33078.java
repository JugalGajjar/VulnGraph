import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XssVulnerableServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        
        // Improperly handling user input by directly embedding it in the response
        String output = "<p>User input: " + userInput + "</p>";
        
        response.getWriter().write(output);
    }
}