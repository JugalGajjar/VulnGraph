import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter the IP address to ping: ");
        String ipAddress = reader.readLine();
        
        // Vulnerable code - directly concatenating user input into the command
        String command = "ping " + ipAddress;
        
        // Execute the command
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader inputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = inputReader.readLine()) != null) {
            System.out.println(line);
        }
        
    }
}