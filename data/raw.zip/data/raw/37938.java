import java.util.Objects;

public final class Range {
    private final int start;
    private final int end;

    public Range(int start, int end) {
        if (start > end) {
            throw new IllegalArgumentException("Start must not exceed end");
        }
        this.start = start;
        this.end = end;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public int length() {
        return end - start + 1;
    }

    public boolean contains(int value) {
        return value >= start && value <= end;
    }

    public boolean contains(Range other) {
        Objects.requireNonNull(other);
        return this.start <= other.start && this.end >= other.end;
    }

    public boolean overlaps(Range other) {
        Objects.requireNonNull(other);
        return this.start <= other.end && other.start <= this.end;
    }

    public Range intersection(Range other) {
        Objects.requireNonNull(other);
        if (!this.overlaps(other)) {
            return null;
        }
        int newStart = Math.max(this.start, other.start);
        int newEnd = Math.min(this.end, other.end);
        return new Range(newStart, newEnd);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Range)) return false;
        Range range = (Range) o;
        return start == range.start && end == range.end;
    }

    @Override
    public int hashCode() {
        return Objects.hash(start, end);
    }

    @Override
    public String toString() {
        return "[" + start + ", " + end + "]";
    }
}