import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String userInput = request.getParameter("input");
        
        // Vulnerable code: User input is directly embedded into the HTML response without proper sanitization
        String htmlResponse = "<html><body><h1>Welcome " + userInput + "</h1></body></html>";
        
        PrintWriter out = response.getWriter();
        out.println(htmlResponse);
    }
}