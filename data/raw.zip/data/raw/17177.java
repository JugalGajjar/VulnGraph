import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XSSVulnerableServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        String responseHtml = "<html><body><h1>User Input: " + userInput + "</h1></body></html>";
        response.getWriter().write(responseHtml);
    }
}