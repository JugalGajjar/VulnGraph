import java.util.Scanner;

public class BufferOverflowVulnerability {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String name = scanner.next();

        // Vulnerability: If the user enters a name longer than 10 characters,
        // it will cause a buffer overflow because the 'buffer' array has a fixed size of 10.
        char[] buffer = new char[10];
        name.getChars(0, name.length(), buffer, 0);

        System.out.println("Hello, " + new String(buffer));
    }
}