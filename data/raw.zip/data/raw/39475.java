import java.util.InputMismatchException;
import java.util.Scanner;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("1. Celsius to Fahrenheit");
                System.out.println("2. Fahrenheit to Celsius");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");
                int option = scanner.nextInt();
                if (option == 3) {
                    break;
                } else if (option < 1 || option > 3) {
                    System.out.println("Invalid option. Please choose a valid option.");
                    continue;
                }
                System.out.print("Enter temperature value: ");
                double temperature = scanner.nextDouble();
                if (option == 1) {
                    double fahrenheit = celsiusToFahrenheit(temperature);
                    System.out.printf("%.2f Celsius is equal to %.2f Fahrenheit%n", temperature, fahrenheit);
                } else if (option == 2) {
                    double celsius = fahrenheitToCelsius(temperature);
                    System.out.printf("%.2f Fahrenheit is equal to %.2f Celsius%n", temperature, celsius);
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next();
            }
        }
        scanner.close();
    }

    private static double celsiusToFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    private static double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }
}