import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a command to execute: ");
        String userInput = reader.readLine();
        
        // Vulnerable code - user input is directly passed to the command execution
        Process process = Runtime.getRuntime().exec("ls " + userInput);
        
        BufferedReader processOutputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = processOutputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}