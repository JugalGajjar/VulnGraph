import java.sql.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class FractalPatternDatabase {

    private static final ConcurrentHashMap<Integer, Connection> pool = new ConcurrentHashMap<>();
    private static final AtomicInteger nextId = new AtomicInteger(1);

    private static final String URL = "jdbc:mysql://localhost:3306/fractal_patterns";
    private static final String USER = "username";
    private static final String PASSWORD = "password";

    public static Connection getConnection() throws SQLException {
        int id = nextId.getAndIncrement();
        return pool.computeIfAbsent(id, k -> {
            try {
                return DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (SQLException e) {
                throw new RuntimeException("Failed to acquire database connection", e);
            }
        });
    }

    public static void releaseConnection(Connection connection) {
        pool.remove(connection);
    }


    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            String query = "INSERT INTO patterns (name, seed, iterations) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, "Mandelbrot");
            statement.setInt(2, 42);
            statement.setInt(3, 1000);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}