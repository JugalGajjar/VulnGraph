import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XSSVulnerableCode {

    public void handleUserInput(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        
        // Improperly handling user input without sanitization
        String output = "<div>" + userInput + "</div>";

        response.getWriter().write(output);
    }
}