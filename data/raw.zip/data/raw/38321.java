import java.util.Objects;

public final class Version implements Comparable<Version> {
    private final int major;
    private final int minor;
    private final int patch;

    public Version(int major, int minor, int patch) {
        if (major < 0 || minor < 0 || patch < 0) {
            throw new IllegalArgumentException("Version numbers must be non-negative");
        }
        this.major = major;
        this.minor = minor;
        this.patch = patch;
    }

    public Version(String version) {
        if (version == null || version.trim().isEmpty()) {
            throw new IllegalArgumentException("Version string must not be null or empty");
        }
        String[] parts = version.trim().split("\\.");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Version string must have exactly three components separated by dots");
        }
        try {
            major = Integer.parseInt(parts[0]);
            minor = Integer.parseInt(parts[1]);
            patch = Integer.parseInt(parts[2]);
            if (major < 0 || minor < 0 || patch < 0) {
                throw new IllegalArgumentException("Version numbers must be non-negative");
            }
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Version components must be integers");
        }
    }

    public int getMajor() { return major; }
    public int getMinor() { return minor; }
    public int getPatch() { return patch; }

    @Override public int compareTo(Version other) {
        Objects.requireNonNull(other);
        int cmp = Integer.compare(major, other.major);
        if (cmp != 0) return cmp;
        cmp = Integer.compare(minor, other.minor);
        if (cmp != 0) return cmp;
        return Integer.compare(patch, other.patch);
    }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Version)) return false;
        Version v = (Version) o;
        return major == v.major && minor == v.minor && patch == v.patch;
    }

    @Override public int hashCode() {
        return Objects.hash(major, minor, patch);
    }

    @Override public String toString() {
        return major + "." + minor + "." + patch;
    }
}