package aero.stellar.navigation;

import java.time.Instant;
import java.util.Objects;

/**
 * Calculates the optimal trajectory correction for an interplanetary probe
 * that must perform a gravity assist around a minor moon to reach a
 * Kuiper-belt target.
 */
public final class OberthGravityAssistStrategy {

    /** Context holding immutable mission data. */
    public static final class TrajectoryContext {
        public final double hyperbolicExcessSpeed; // km/s
        public final double targetSphereOfInfluence; // km
        public final Instant epoch;
        public final double probeMass; // kg

        public TrajectoryContext(double hyperbolicExcessSpeed,
                                 double targetSphereOfInfluence,
                                 Instant epoch,
                                 double probeMass) {
            if (hyperbolicExcessSpeed <= 0 || targetSphereOfInfluence <= 0 || probeMass <= 0) {
                throw new IllegalArgumentException("All physical parameters must be positive.");
            }
            this.hyperbolicExcessSpeed = hyperbolicExcessSpeed;
            this.targetSphereOfInfluence = targetSphereOfInfluence;
            this.epoch = Objects.requireNonNull(epoch, "epoch");
            this.probeMass = probeMass;
        }
    }

    /** Functional strategy interface. */
    public interface CorrectionStrategy {
        /**
         * Returns ?v in km/s required to place the probe on the outgoing
         * hyperbolic exit to the Kuiper object.
         *
         * @param ctx immutable mission context
         * @return non-NaN finite ?v in km/s
         * @throws IllegalStateException if the maneuver is impossible
         */
        double computeDeltaV(TrajectoryContext ctx);
    }

    /**
     * Exponentially damped radial correction optimized for low-thrust ion engines.
     */
    public static final class IonDrivePerturbation implements CorrectionStrategy {
        @Override
        public double computeDeltaV(TrajectoryContext ctx) {
            validate(ctx);
            double ve = ctx.hyperbolicExcessSpeed;
            double r = ctx.targetSphereOfInfluence;
            double kappa = 0.87; // empirical damping from JPL ephemeriDE
            return ve * (1.0 - Math.exp(-kappa * r / ve));
        }
    }

    /**
     * Ballistic Oberth-maximizing bi-parabolic maneuver around small moon.
     * Uses non-linear root of Barkers equation approximation.
     */
    public static final class OberthParabolicSlingshot implements CorrectionStrategy {
        @Override
        public double computeDeltaV(TrajectoryContext ctx) {
            validate(ctx);
            double ve = ctx.hyperbolicExcessSpeed;
            double mu = 4.2828e4; // gravitational param of minor moon (km^3/s^2)
            // Solve Barker's equation inverse
            double a = mu / (ve * ve); // semi-major axis
            if (a < 0) {
                throw new IllegalStateException("Negative energy orbit impossible.");
            }
            double periRadius = 1.2 * ctx.probeMass; // avoid lithobraking
            if (periRadius <= 0) {
                throw new IllegalStateException("Periapsis inside moon surface.");
            }
            // Energy augmentation via Oberth
            double oberthV = Math.sqrt(ve * ve + 2 * mu / periRadius);
            return oberthV - ve;
        }
    }

    /**
     * Executes correction and returns final mission energy.
     */
    public static final class MissionPlanner {
        private final TrajectoryContext ctx;
        private final CorrectionStrategy strategy;

        public MissionPlanner(TrajectoryContext ctx, CorrectionStrategy strategy) {
            this.ctx = Objects.requireNonNull(ctx);
            this.strategy = Objects.requireNonNull(strategy);
        }

        public double executeBurn() {
            double deltaV = strategy.computeDeltaV(ctx);
            return ctx.hyperbolicExcessSpeed + deltaV;
        }
    }

    private static void validate(TrajectoryContext ctx) {
        if (!Double.isFinite(ctx.hyperbolicExcessSpeed)) {
            throw new IllegalArgumentException("Non-finite hyperbolic speed.");
        }
    }
}