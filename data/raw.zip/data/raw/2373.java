import java.io.*;

public class XSSVulnerableCode {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter your name: ");
        String name = br.readLine();

        System.out.println("Hello, " + name + "!"); // This line is vulnerable to XSS

        // Assuming an attacker enters the following input:
        // <script>alert('XSS attack!')</script>
    }
}