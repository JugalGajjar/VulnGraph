import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DateValidator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        while (true) {
            try {
                System.out.print("Enter a date (yyyy-MM-dd) or 'q' to quit: ");
                String input = scanner.nextLine();

                if (input.equalsIgnoreCase("q")) {
                    break;
                }

                LocalDate date = LocalDate.parse(input, formatter);
                System.out.println("Valid date: " + date);
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a date in the format yyyy-MM-dd.");
                scanner.next(); // discard invalid input
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        }

        scanner.close();
    }
}