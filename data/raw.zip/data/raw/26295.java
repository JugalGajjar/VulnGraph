import java.sql.*;

public class SQLInjectionVulnerableCode {

    public static void main(String[] args) {
        try {
            // Simulated user input
            String userInput = "'; DROP TABLE users; --";

            // Vulnerable code where user input is directly concatenated into the SQL query
            String query = "SELECT * FROM users WHERE username = '" + userInput + "'";

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "username", "password");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                System.out.println("Username: " + resultSet.getString("username"));
                System.out.println("Password: " + resultSet.getString("password"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}