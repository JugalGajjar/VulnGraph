import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String fileName = args[0]; // User input for file name
        String basePath = "/var/www/files/"; // Base path where files are stored

        File file = new File(basePath + fileName);
        
        try (FileInputStream fis = new FileInputStream(file)) {
            int content;
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}