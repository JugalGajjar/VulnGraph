import java.io.IOException;
import javax.servlet.http.*;

public class XSSVulnerableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userInput = request.getParameter("input");
        String responseText = "Welcome, " + userInput + "!";

        response.getWriter().println(responseText);
    }
}