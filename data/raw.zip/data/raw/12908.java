import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input from a form field
        String userInput = "<script>alert('XSS Vulnerability')</script>";

        // Improperly handling user input by directly printing it to HTML output
        System.out.println("<p>User Input: " + userInput + "</p>");
    }
}