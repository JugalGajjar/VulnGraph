import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.nio.file.Path;
import java.util.Scanner;

public class PathTraversalExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter file name:");
        String fileName = scanner.nextLine();
        
        File file = new File("/path/to/directory/" + fileName);
        
        if (file.exists()) {
            try {
                Path filePath = file.toPath();
                byte[] fileData = Files.readAllBytes(filePath);
                System.out.println("File contents: " + new String(fileData));
            } catch (IOException e) {
                System.out.println("Error reading file.");
            }
        } else {
            System.out.println("File not found.");
        }
    }
}