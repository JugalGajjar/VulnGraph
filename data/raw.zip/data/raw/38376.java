import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

public class FileWordCounter {
    private static final Pattern WORD_PATTERN = Pattern.compile("\\b\\w+\\b");

    public static void main(String[] args) {
        if (args == null || args.length != 1) {
            System.err.println("Usage: java FileWordCounter <path-to-text-file>");
            System.exit(1);
        }

        Path filePath = Paths.get(args[0]);
        if (!Files.isRegularFile(filePath) || !Files.isReadable(filePath)) {
            System.err.println("Error: File does not exist or is not readable: " + filePath);
            System.exit(2);
        }

        try {
            long wordCount = countWords(filePath);
            System.out.println("Word count: " + wordCount);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            System.exit(3);
        }
    }

    private static long countWords(Path path) throws IOException {
        long count = 0;
        try (var lines = Files.lines(path)) {
            for (String line : (Iterable<String>) lines::iterator) {
                count += WORD_PATTERN.matcher(line).results().count();
            }
        }
        return count;
    }
}