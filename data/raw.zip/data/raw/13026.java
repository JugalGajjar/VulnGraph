import java.io.IOException;
import java.io.PrintWriter;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        String userInput = "<script>alert('XSS Attack!')</script>";

        PrintWriter out = new PrintWriter(System.out);

        out.println("<html>");
        out.println("<body>");
        out.println("<h1>Welcome, " + userInput + "</h1>");
        out.println("</body>");
        out.println("</html>");

        out.flush();
    }
}