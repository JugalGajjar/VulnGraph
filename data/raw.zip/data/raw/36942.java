import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WebCrawler {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java WebCrawler <startUrl>");
            System.exit(1);
        }

        String startUrl = args[0];
        if (!isValidUrl(startUrl)) {
            System.err.println("Invalid URL: " + startUrl);
            System.exit(1);
        }

        WebCrawler crawler = new WebCrawler();
        List<String> collectedUrls = crawler.crawl(startUrl, 3, 10);
        collectedUrls.forEach(System.out::println);
    }

    private static boolean isValidUrl(String url) {
        try {
            new URL(url).toURI();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<String> crawl(String startUrl, int maxDepth, int maxThreads) {
        List<String> result = new ArrayList<>();
        crawlRecursive(startUrl, 0, maxDepth, maxThreads, result);
        return result;
    }

    private void crawlRecursive(String url, int depth, int maxDepth, int maxThreads, List<String> accumulator) {
        if (!isValidUrl(url) || depth > maxDepth) {
            return;
        }

        synchronized (accumulator) {
            if (accumulator.contains(url)) {
                return;
            }
            accumulator.add(url);
        }

        try {
            List<String> links = fetchLinks(url);
            if (depth == maxDepth) {
                return;
            }

            ExecutorService pool = Executors.newFixedThreadPool(maxThreads);
            List<Callable<Void>> tasks = new ArrayList<>();
            for (String link : links) {
                tasks.add(() -> {
                    crawlRecursive(link, depth + 1, maxDepth, maxThreads, accumulator);
                    return null;
                });
            }
            List<Future<Void>> futures = pool.invokeAll(tasks);
            for (Future<Void> f : futures) {
                f.get();
            }
            pool.shutdown();
        } catch (Exception e) {
            // silently ignore for production robustness
        }
    }

    private List<String> fetchLinks(String urlString) throws IOException {
        List<String> links = new ArrayList<>();
        URL url = new URL(urlString);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))) {
            String line;
            StringBuilder content = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
            Pattern pattern = Pattern.compile("href=\"([^\"]+)\"");
            Matcher matcher = pattern.matcher(content);
            while (matcher.find()) {
                String link = matcher.group(1);
                if (link.startsWith("http")) {
                    links.add(link);
                }
            }
        }
        return links;
    }
}