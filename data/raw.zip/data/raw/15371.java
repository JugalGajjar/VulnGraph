import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the file name to read: ");
        String fileName = scanner.nextLine();

        try {
            File file = new File(fileName);
            FileReader fileReader = new FileReader(file);
            int character;
            while ((character = fileReader.read()) != -1) {
                System.out.print((char) character);
            }
            fileReader.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}