import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        // Simulating user input
        String userInput = "<script>alert('XSS Vulnerability');</script>";

        // Improperly handling user input without proper sanitization
        String output = "<p>" + userInput + "</p>";

        // Display the output
        System.out.println(output);
    }
}