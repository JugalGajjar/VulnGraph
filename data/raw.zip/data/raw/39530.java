import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Enter the first number:");
                double num1 = scanner.nextDouble();
                System.out.println("Enter the operator (+, -, *, /):");
                char operator = scanner.next().charAt(0);
                System.out.println("Enter the second number:");
                double num2 = scanner.nextDouble();
                double result = calculate(num1, num2, operator);
                System.out.println("Result: " + result);
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            } catch (ArithmeticException e) {
                System.out.println("Cannot divide by zero.");
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid operator.");
            }
        }
    }

    private static double calculate(double num1, double num2, char operator) {
        switch (operator) {
            case '+':
                return num1 + num2;
            case '-':
                return num1 - num2;
            case '*':
                return num1 * num2;
            case '/':
                if (num2 == 0) {
                    throw new ArithmeticException();
                }
                return num1 / num2;
            default:
                throw new IllegalArgumentException();
        }
    }
}