package com.cryo.vault;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Arrays;

/**
 * An ephemeral message vault that self-destructs messages after a configurable
 * TTL (time-to-live) period while adding plausible deniability.
 *
 * Messages are encrypted with a key derived from the TTL itself, meaning
 * the key evaporates naturally after expirationno persistent material is
 * ever stored.  A 4-byte sliding checksum is embedded to detect tampering
 * without revealing message existence.
 *
 * Thread-safe, zero-dependency, single-file implementation.
 */
public final class EphemeralMessageVault {

    private static final int CHECKSUM_LEN = 4;
    private static final int IV_LEN       = 16;

    private EphemeralMessageVault() {}

    /**
     * Stores an arbitrary byte sequence inside an encrypted capsule that will
     * become undecryptable after {@code ttlSeconds} seconds.
     *
     * @param payload    data to safeguard
     * @param ttlSeconds time to live in seconds; must be 186 400 (24 h)
     * @return opaque envelope (encrypted + MAC)
     * @throws IllegalArgumentException if TTL out of range
     * @throws SecurityException        if encryption fails
     */
    public static byte[] seal(byte[] payload, int ttlSeconds) {
        validateTtl(ttlSeconds);
        Instant expiry = Instant.now().plusSeconds(ttlSeconds);
        byte[] ttlKey  = deriveKey(expiry);

        try {
            SecureRandom sr = new SecureRandom();
            byte[] iv = new byte[IV_LEN];
            sr.nextBytes(iv);

            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(ttlKey, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(iv));

            byte[] cipherText = cipher.doFinal(payload);
            byte[] checksum   = checksum(payload);

            // envelope = iv | checksum | cipherText
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(iv);
            baos.write(checksum);
            baos.write(cipherText);

            // burn sensitive material
            Arrays.fill(ttlKey, (byte) 0);

            return baos.toByteArray();
        } catch (Exception e) {
            throw new SecurityException("Sealing failed", e);
        }
    }

    /**
     * Attempts to open an envelope.  After TTL expiry this will always fail
     * with a {@code SecurityException}.
     *
     * @param envelope   sealed capsule returned from {@link #seal}
     * @param ttlSeconds identical TTL used in sealing
     * @return original plaintext
     * @throws IllegalArgumentException if envelope malformed
     * @throws SecurityException        if TTL expired or MAC mismatch
     */
    public static byte[] open(byte[] envelope, int ttlSeconds) {
        validateTtl(ttlSeconds);
        Instant expiry = Instant.now().plusSeconds(-ttlSeconds);
        byte[] ttlKey  = deriveKey(expiry);

        try (ByteArrayInputStream bais = new ByteArrayInputStream(envelope)) {
            byte[] iv = new byte[IV_LEN];
            int read = bais.read(iv);
            if (read != IV_LEN)
                throw new IllegalArgumentException("Truncated IV");

            byte[] storedChecksum = new byte[CHECKSUM_LEN];
            read = bais.read(storedChecksum);
            if (read != CHECKSUM_LEN)
                throw new IllegalArgumentException("Truncated checksum");

            byte[] cipherText = bais.readAllBytes();

            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(ttlKey, "AES");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv));

            byte[] plain = cipher.doFinal(cipherText);

            if (!Arrays.equals(storedChecksum, checksum(plain))) {
                throw new SecurityException("Integrity check failed");
            }

            Arrays.fill(ttlKey, (byte) 0);
            return plain;
        } catch (Exception e) {
            // scrub before bubbling
            throw new SecurityException("Failed to open vault", e);
        }
    }

    /* ---------------------------------------------------------------------- */

    private static void validateTtl(int ttl) {
        if (ttl < 1 || ttl > 86_400)
            throw new IllegalArgumentException("TTL out of 186400 range");
    }

    private static byte[] deriveKey(Instant instant) {
        // deterministic, irreversible key seeded from truncated epoch seconds
        long stamp = instant.getEpochSecond();
        ByteBuffer buffer = ByteBuffer.allocate(16);
        buffer.putLong(stamp);
        buffer.putLong(stamp ^ 0xDEADBEEFCAFEBABEL);
        byte[] raw = buffer.array();
        // simple whitening & AES key length
        for (int i = 0; i < raw.length; i++) {
            raw[i] ^= (byte) (i * 31);
        }
        return raw;
    }

    private static byte[] checksum(byte[] data) {
        ByteBuffer buf = ByteBuffer.allocate(CHECKSUM_LEN);
        int crc = 0xFFFF;
        for (byte b : data) {
            crc ^= (b & 0xFF);
            for (int i = 0; i < 8; i++) {
                int odd = crc & 1;
                crc >>>= 1;
                if (odd != 0) crc ^= 0x8408;
            }
        }
        // use only low 32 bits (4 bytes)
        buf.putInt(crc);
        return buf.array();
    }
}