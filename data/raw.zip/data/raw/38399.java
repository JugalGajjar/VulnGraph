import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileLineCounter {

    /**
     * Counts the number of lines in the given file.
     *
     * @param filePath the path to the file
     * @return the number of lines
     * @throws IllegalArgumentException if the file does not exist, is not a file, or cannot be read
     * @throws IOException              if an I/O error occurs while reading the file
     */
    public static long countLines(String filePath) throws IOException {
        if (filePath == null || filePath.isBlank()) {
            throw new IllegalArgumentException("File path must not be null or empty.");
        }

        File file = new File(filePath);
        if (!file.exists()) {
            throw new IllegalArgumentException("File does not exist: " + filePath);
        }
        if (!file.isFile()) {
            throw new IllegalArgumentException("Path is not a file: " + filePath);
        }
        if (!file.canRead()) {
            throw new IllegalArgumentException("File cannot be read: " + filePath);
        }

        long lines = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            while (reader.readLine() != null) {
                lines++;
            }
        }
        return lines;
    }

    /**
     * Entry point. Expects a single argument: the path to the file.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java FileLineCounter <file-path>");
            System.exit(1);
        }

        String path = args[0];
        try {
            long lineCount = countLines(path);
            System.out.println("Number of lines: " + lineCount);
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid input: " + e.getMessage());
            System.exit(2);
        } catch (IOException e) {
            System.err.println("I/O error while reading file: " + e.getMessage());
            System.exit(3);
        }
    }
}