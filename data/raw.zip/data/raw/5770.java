import java.io.*;

public class InsecureDeserializationExample {

    public static void main(String[] args) {
        try {
            String userInput = "user_input_here"; // Simulated user input
            byte[] serializedData = userInput.getBytes();
            
            ByteArrayInputStream bais = new ByteArrayInputStream(serializedData);
            ObjectInputStream ois = new ObjectInputStream(bais);
            
            Object obj = ois.readObject(); // Deserializing user input
            
            System.out.println(obj.toString());
            
            ois.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}