import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;

public final class DirectorySize {

    public static long size(Path path) throws IOException {
        if (path == null) {
            throw new IllegalArgumentException("Path must not be null.");
        }
        if (!Files.exists(path)) {
            throw new NoSuchFileException(path.toString());
        }

        try (Stream<Path> walk = Files.walk(path)) {
            return walk.filter(Files::isRegularFile)
                       .mapToLong(p -> {
                           try {
                               return Files.size(p);
                           } catch (IOException e) {
                               throw new UncheckedIOException(e);
                           }
                       })
                       .sum();
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    private DirectorySize() {
        throw new AssertionError("Utility class");
    }
}