import java.io.*;

public class XSSVulnerableCode {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Enter your name: ");
            String userInput = reader.readLine();
            
            System.out.println("Hello, " + userInput + "!"); // Improperly handling user input
            
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}