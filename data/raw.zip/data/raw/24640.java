import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerability {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a directory name: ");
        String directoryName = reader.readLine();
        
        String command = "ls " + directoryName; // Assume user input is directly concatenated into the command
        
        Process process = Runtime.getRuntime().exec(command);
        BufferedReader processOutputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        
        String line;
        while ((line = processOutputReader.readLine()) != null) {
            System.out.println(line);
        }
        
        process.waitFor();
    }
}