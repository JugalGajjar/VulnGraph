import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerability {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter the IP address to ping: ");
        String ipAddress = reader.readLine();
        
        // Vulnerable code: user input is directly passed to the command line
        String command = "ping " + ipAddress;
        
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = outputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}