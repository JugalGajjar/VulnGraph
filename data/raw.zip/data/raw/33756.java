import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerability {

    public static void main(String[] args) {
        try {
            // Vulnerable code - user input is directly used in a command execution
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a command to execute: ");
            String userInput = br.readLine();

            // Execute the command entered by the user
            Runtime rt = Runtime.getRuntime();
            Process process = rt.exec("ping " + userInput);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}