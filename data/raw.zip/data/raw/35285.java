import java.util.Scanner;

public class BufferOverflowExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter your name: ");
        String input = scanner.next();
        
        // Assuming the input size should be limited to 10 characters
        char[] buffer = new char[10];
        
        // Copying the input into the buffer without checking its length
        for (int i = 0; i < input.length(); i++) {
            buffer[i] = input.charAt(i);
        }
        
        System.out.println("Your name is: " + new String(buffer));
    }
}