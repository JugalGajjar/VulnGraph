import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter file name: ");
        String fileName = scanner.nextLine();
        
        File file = new File("/path/to/directory/" + fileName);
        
        try {
            if (file.exists()) {
                System.out.println("File content:");
                
                Scanner fileScanner = new Scanner(file);
                
                while (fileScanner.hasNextLine()) {
                    System.out.println(fileScanner.nextLine());
                }
                
                fileScanner.close();
            } else {
                System.out.println("File not found.");
            }
        } catch (IOException e) {
            System.out.println("Error reading the file.");
            e.printStackTrace();
        }
        
        scanner.close();
    }
}