import java.util.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;

/**
 * Repository for maintaining and querying a tamper-evident ledger of quantum-signature
 * snapshots from ultra-cold atomic clocks aboard a decentralized satellite cluster.
 *
 * The repository ensures immutability by chaining SHA-256 digests of each snapshot,
 * detects fork anomalies via vector-clock like comparisons, and supports temporal
 * range queries down to nanosecond precision for relativistic experiments.
 */
public final class QuantumClockLedgerRepository {

    private final NavigableMap<Instant, QuantumClockSnapshot> ledger = new TreeMap<>();
    private final Deque<ChronoProof> proofChain = new ArrayDeque<>();

    /**
     * Inserts a validated snapshot into the immutable ledger.
     *
     * @param snapshot the atomic-clock snapshot to append
     * @throws EntanglementViolationException if chain integrity is broken
     * @throws TemporalParadoxException      if timestamp is not monotonic
     */
    public void appendSnapshot(QuantumClockSnapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        if (!snapshot.isSignatureValid()) {
            throw new EntanglementViolationException("Invalid quantum signature");
        }
        if (!ledger.isEmpty() && !snapshot.timestamp().isAfter(ledger.lastKey())) {
            throw new TemporalParadoxException("Non-monotonic timestamp");
        }
        String prevHash = proofChain.isEmpty() ? "GENESIS" : proofChain.peekLast().currentHash();
        String proofHash = hash(prevHash + "|" + snapshot.hashString());
        proofChain.addLast(new ChronoProof(snapshot.timestamp(), proofHash));
        ledger.put(snapshot.timestamp(), snapshot);
    }

    /**
     * Returns the latest snapshot whose timestamp is not after the provided instant.
     *
     * @param upperBound exclusive upper bound
     * @return valid snapshot or empty Optional if ledger is empty
     */
    public Optional<QuantumClockSnapshot> latestBefore(Instant upperBound) {
        Map.Entry<Instant, QuantumClockSnapshot> e = ledger.floorEntry(upperBound);
        return Optional.ofNullable(e).map(Map.Entry::getValue);
    }

    /**
     * Detects whether the current ledger diverges with a given foreign proof chain.
     *
     * @param foreignProof the external chain to compare against
     * @return true if divergence detected
     */
    public boolean hasForked(List<ChronoProof> foreignProof) {
        int len = Math.min(proofChain.size(), foreignProof.size());
        Iterator<ChronoProof> itLocal = proofChain.iterator();
        Iterator<ChronoProof> itForeign = foreignProof.iterator();
        for (int i = 0; i < len; i++) {
            if (!itLocal.next().equals(itForeign.next())) return true;
        }
        return proofChain.size() != foreignProof.size();
    }

    /**
     * Computes an aggregate drift correction for a closed interval of snapshots.
     *
     * @param fromInclusive interval start
     * @param toExclusive   interval end
     * @return signed nanoseconds of cumulative drift
     */
    public long relativisticDrift(Instant fromInclusive, Instant toExclusive) {
        if (fromInclusive.isAfter(toExclusive)) {
            throw new TemporalParadoxException("Invalid interval");
        }
        SortedMap<Instant, QuantumClockSnapshot> slice = ledger.subMap(fromInclusive, toExclusive);
        return slice.values().stream()
                     .mapToLong(QuantumClockSnapshot::drift)
                     .sum();
    }

    // ---------- helpers ----------
    private static String hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes());
            return new BigInteger(1, bytes).toString(16);
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }

    /** Record capturing the immutable attributes of a quantum-clock measurement. */
    public record QuantumClockSnapshot(Instant timestamp,
                                       BigInteger quantumSignature,
                                       long drift,
                                       byte[] entropy) {
        boolean isSignatureValid() {
            return quantumSignature != null
                    && !quantumSignature.testBit(0);        // even parity expected
        }
        String hashString() {
            return timestamp.toString() + "|" + quantumSignature + "|" + drift + "|" + Arrays.hashCode(entropy);
        }
    }

    /** Proof object chaining hashes for tamper detection. */
    public record ChronoProof(Instant timestamp, String currentHash) {}

    public static class EntanglementViolationException extends RuntimeException {
        public EntanglementViolationException(String msg) { super(msg); }
    }

    public static class TemporalParadoxException extends RuntimeException {
        public TemporalParadoxException(String msg) { super(msg); }
    }
}