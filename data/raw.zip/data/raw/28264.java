import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class XSSVulnerableServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("input");
        
        // Improper handling of user input leads to XSS vulnerability
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<p>User Input: " + userInput + "</p>"); // User input is directly reflected back without proper sanitization
        out.println("</body>");
        out.println("</html>");
    }
}