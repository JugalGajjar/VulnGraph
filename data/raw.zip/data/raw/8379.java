import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a file name to display its contents: ");
        String fileName = reader.readLine();
        
        // Vulnerability: User input directly passed to the command without proper validation
        String command = "cat " + fileName; 
        
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader processOutputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        
        String line;
        while ((line = processOutputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}