import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the file name: ");
        String fileName = scanner.nextLine();

        String filePath = "/path/to/files/" + fileName; // User input is directly appended to the file path
        
        try {
            File file = new File(filePath);
            FileReader fr = new FileReader(file);
            
            int c;
            while ((c = fr.read()) != -1) {
                System.out.print((char) c);
            }
            
            fr.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}