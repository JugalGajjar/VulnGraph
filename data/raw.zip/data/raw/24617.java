import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerable {

    public static void main(String[] args) {
        try {
            System.out.print("Enter a website to ping: ");
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String website = reader.readLine();

            Process p = Runtime.getRuntime().exec("ping " + website);

            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = input.readLine()) != null) {
                System.out.println(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}