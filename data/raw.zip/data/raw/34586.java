import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.nio.file.Paths;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = "../../../../../etc/passwd";
        String basePath = "/var/www/public/";
        
        String filePath = basePath + userInput;
        
        try {
            File file = new File(filePath);
            byte[] fileContent = Files.readAllBytes(Paths.get(file.getPath()));
            
            System.out.println(new String(fileContent));
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}