package io.cognify.thermoflare.cryo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * CryoFluidCompositionValidator validates complex cryogenic-fluid shorthand strings
 * used by inter-planetary refrigeration engineers.
 *
 * Syntax:
 *   CRYO_EXPR := BASE {SPEC}{*RATIO}
 *   BASE      := He|N2|CH4|CO2|NH3
 *   SPEC      := [A-Z][a-z]?\d*
 *   RATIO     := \d+(\.\d+)?(M|K|µ|n)?
 *
 * Examples:
 *   "N2O1*2.5K"           (Nitrous-Oxide blend at 2.5 K)
 *   "CH4C10H22*0.33M"     (Methane-Decane blend at 0.33 M)
 *   "CO2NH3O2*1.2µ"       (Carbon-Dioxide, Ammonia, Oxygen at 1.2 µmol)
 */
public final class CryoFluidCompositionValidator {

    private static final String BASE_PATTERN = "(He|N2|CH4|CO2|NH3)";
    private static final String ELEMENT_SPEC   = "[A-Z][a-z]?\\d*";
    private static final String RATIO_SPEC     = "\\d+(\\.\\d+)?[M,K,µ,n]?";
    private static final String CRYO_REGEX =
            "^" + BASE_PATTERN + "(" + ELEMENT_SPEC + "+\\*" + RATIO_SPEC + ")$";

    private static final Pattern PATTERN = Pattern.compile(CRYO_REGEX);

    private CryoFluidCompositionValidator() { /* static utility class */ }

    /**
     * Validates and returns the parsed structure without exceptions on mismatch.
     *
     * @param cryoShorthand the cryo-fluid shorthand
     * @return ParsedCryo if valid
     * @throws IllegalArgumentException on null or empty input
     */
    public static ParsedCryo parse(String cryoShorthand) {
        if (cryoShorthand == null || cryoShorthand.trim().isEmpty()) {
            throw new IllegalArgumentException("Cryo shorthand must not be null or empty.");
        }

        Matcher m = PATTERN.matcher(cryoShorthand.trim());
        if (!m.matches()) {
            throw new IllegalArgumentException("Invalid cryo-fluid shorthand: " + cryoShorthand);
        }

        String base = m.group(1);
        String specPart = m.group(2);
        int sep = specPart.indexOf('*');
        String spec = specPart.substring(0, sep);
        String ratio = specPart.substring(sep + 1);

        return new ParsedCryo(base, spec, ratio);
    }

    /**
     * Immutable parsed cryogenic fluid descriptor.
     */
    public static final class ParsedCryo {
        public final String baseFluid;
        public final String elementSpec;
        public final String ratio;

        private ParsedCryo(String baseFluid, String elementSpec, String ratio) {
            this.baseFluid = baseFluid;
            this.elementSpec = elementSpec;
            this.ratio = ratio;
        }

        @Override
        public String toString() {
            return baseFluid + "+" + elementSpec + "*" + ratio;
        }
    }
}