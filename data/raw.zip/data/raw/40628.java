import java.util.InputMismatchException;
import java.util.Scanner;

public class RomanNumeralConverter {

    private static final int[] VALUES = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static final String[] ROMAN_LITERALS = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static String convertToRoman(int number) {
        if (number < 1 || number > 3999) {
            throw new IllegalArgumentException("Number must be between 1 and 3999");
        }

        StringBuilder roman = new StringBuilder();
        for (int i = 0; i < VALUES.length; i++) {
            while (number >= VALUES[i]) {
                roman.append(ROMAN_LITERALS[i]);
                number -= VALUES[i];
            }
        }
        return roman.toString();
    }

    public static int convertToInteger(String roman) {
        roman = roman.toUpperCase();
        int result = 0;
        int i = 0;
        while (i < roman.length()) {
            boolean found = false;
            for (int j = 0; j < ROMAN_LITERALS.length; j++) {
                if (roman.startsWith(ROMAN_LITERALS[j], i)) {
                    result += VALUES[j];
                    i += ROMAN_LITERALS[j].length();
                    found = true;
                    break;
                }
            }
            if (!found) {
                throw new IllegalArgumentException("Invalid Roman numeral");
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Enter 'r' to convert to Roman numeral, 'i' to convert from Roman numeral, 'q' to quit:");
                String input = scanner.next().trim().toLowerCase();
                if (input.equals("q")) {
                    break;
                } else if (input.equals("r")) {
                    System.out.print("Enter a number (1-3999): ");
                    int number = scanner.nextInt();
                    System.out.println(convertToRoman(number));
                } else if (input.equals("i")) {
                    System.out.print("Enter a Roman numeral: ");
                    String roman = scanner.next().trim();
                    System.out.println(convertToInteger(roman));
                } else {
                    System.out.println("Invalid option");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input");
                scanner.next(); // Clear invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
        scanner.close();
    }
}