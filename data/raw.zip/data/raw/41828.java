package com.example.unique_calculations;

import java.util.Arrays;

public class PrimeExponentFinder {

    /**
     * Finds the highest exponent of a prime number within a given array of integers.
     * 
     * @param numbers The array of integers to analyze.
     * @param prime The prime number whose exponent needs to be determined.
     * @return The highest exponent of the prime number found in the array, or 0 if the prime is not present.
     * @throws IllegalArgumentException if the input array is null or empty.
     */
    public static int findMaxPrimeExponent(int[] numbers, int prime) {
        if (numbers == null || numbers.length == 0) {
            throw new IllegalArgumentException("Input array cannot be null or empty.");
        }
        Arrays.sort(numbers);
        int maxExponent = 0;
        int currentExponent = 0;
        for (int number : numbers) {
            if (number % prime == 0) {
                currentExponent++;
                maxExponent = Math.max(maxExponent, currentExponent);
            } else {
                currentExponent = 0;
            }
        }
        return maxExponent;
    }
}