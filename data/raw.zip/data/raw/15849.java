import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = "../secretfile.txt"; // User input with path traversal

        String basePath = "/var/www/html/files/"; // Base directory for files

        String filePath = basePath + userInput; // Constructing the file path based on user input

        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);

            int content;
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }

            fis.close();
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}