package astronomy.temporal;

import java.time.*;
import java.time.temporal.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * SiderealTimeConverter converts civil timestamps (UTC) to Greenwich & local
 * Apparent Sidereal Time expressed in fractional hours.  These values are crucial
 * for telescopic pointing algorithms that use equatorial coordinates
 * (right-ascension / declination).  All calculations use the IAU 2006/2000A
 * precession-nutation model coefficients reduced to closed-form polynomials.
 *
 * Thread-safe & immutable.
 */
public final class SiderealTimeConverter {

    private static final double GMST_0_DEG  = 280.46061837;        // J2000.0 value in deg
    private static final double GMST_0_RATE   = 360.98564736629;    // deg/day
    private static final double SECONDS_DAY   = 86_400d;

    private final double longitudeDeg;

    /**
     * Creates the converter for a terrestrial longitude.
     *
     * @param longitudeDeg geographic longitude, positive East [-180..180]
     */
    public SiderealTimeConverter(double longitudeDeg) {
        if (Math.abs(longitudeDeg) > 180)
            throw new IllegalArgumentException("Longitude out of range: " + longitudeDeg);
        this.longitudeDeg = longitudeDeg;
    }

    /**
     * Returns both Greenwich & local apparent sidereal times (in hours)
     * for the supplied UTC instant.
     *
     * @param  utc  instant to convert (must not be null)
     * @return      immutable result record
     */
    public Result convert(Instant utc) {
        Objects.requireNonNull(utc, "utc");

        // Julian day from J2000.0 epoch in TT (delta-T simplified)
        double jd = toJ2000TtDays(utc);
        double jc = jd / 36_525d;               // Julian centuries

        // Earth rotation angle for GMST
        double gmstDeg = GMST_0_DEG
                       + GMST_0_RATE * jd
                       + 0.000387933 * jc * jc
                       - jc * jc * jc / 38_740_000;
        double gmst = normaliseDeg(gmstDeg) / 15d;   // to hours

        double eqe = equationOfEquinoxes(jc);           // nutation correction
        double gast = normaliseHour(gmst + eqe / 15);   // GAST = GMST + eqe
        double last = normaliseHour(gast + longitudeDeg / 15d);

        return new Result(gast, last);
    }

    private static double toJ2000TtDays(Instant utc) {
        // delta-T  69.0s for years 2020-2040 good to <0.1s error
        Instant tt = utc.plusNanos(69_000_000_000L);
        return Duration.between(Instant.parse("2000-01-01T12:00:00Z"), tt).toSeconds() / SECONDS_DAY;
    }

    private static double equationOfEquinoxes(double jc) {
        double dp = nutationInLongitudeArcsec(jc) * Math.PI / 180 / 3600;
        double eps = meanObliquityDeg(jc) * Math.PI / 180;
        return dp * Math.cos(eps);
    }

    private static double nutationInLongitudeArcsec(double jc) {
        double c = jc;
        return -17.2 * Math.sin(125.04 - 1934.14 * c)      // simplified 1-term IAU2000
               - 1.32 * Math.sin(200.9 -  719.99 * c);
    }

    private static double meanObliquityDeg(double jc) {
        return 23.4392794444
               - 0.0130102778 * jc
               - 0.0000001389 * jc * jc
               + 0.00000000555 * jc * jc * jc;
    }

    private static double normaliseDeg(double deg) {
        double v = deg % 360;
        return v < 0 ? v + 360 : v;
    }

    private static double normaliseHour(double h) {
        double v = h % 24;
        return v < 0 ? v + 24 : v;
    }

    /** Immutable transfer object. */
    public static final class Result {
        public final double greenwichApparentSiderealHours;
        public final double localApparentSiderealHours;

        private Result(double gast, double last) {
            this.greenwichApparentSiderealHours = gast;
            this.localApparentSiderealHours    = last;
        }

        @Override
        public String toString() {
            return String.format(Locale.ROOT,
                    "Result{GAST=%.6fh, LAST=%.6fh}",
                    greenwichApparentSiderealHours,
                    localApparentSiderealHours);
        }
    }

    // Quick CLI demo for manual verification
    public static void main(String[] args) {
        SiderealTimeConverter berlin = new SiderealTimeConverter(13.405);
        Result r = berlin.convert(Instant.now());
        System.out.println(r);
    }
}