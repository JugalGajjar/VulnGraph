import java.util.Objects;

public final class TemperatureConverter {
    private TemperatureConverter() {}

    public static double celsiusToFahrenheit(double celsius) {
        validate(celsius);
        return celsius * 9 / 5 + 32;
    }

    public static double celsiusToKelvin(double celsius) {
        validate(celsius);
        return celsius + 273.15;
    }

    public static double fahrenheitToCelsius(double fahrenheit) {
        validate(fahrenheit);
        return (fahrenheit - 32) * 5 / 9;
    }

    public static double fahrenheitToKelvin(double fahrenheit) {
        return celsiusToKelvin(fahrenheitToCelsius(fahrenheit));
    }

    public static double kelvinToCelsius(double kelvin) {
        validate(kelvin);
        if (kelvin < 0) {
            throw new IllegalArgumentException("Kelvin cannot be negative");
        }
        return kelvin - 273.15;
    }

    public static double kelvinToFahrenheit(double kelvin) {
        return celsiusToFahrenheit(kelvinToCelsius(kelvin));
    }

    private static void validate(Double value) {
        if (Objects.isNull(value) || Double.isNaN(value)) {
            throw new IllegalArgumentException("Temperature must be a valid number");
        }
    }
}