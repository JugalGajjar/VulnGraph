import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Enter a command to execute: ");
            String userInput = reader.readLine();
            
            // Vulnerability: User input is directly used in the command without proper validation
            Process process = Runtime.getRuntime().exec("ping " + userInput);
            
            BufferedReader inputStreamReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            
            while ((line = inputStreamReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}