import java.io.*;

public class XSSVulnerability {

    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Enter your name:");
        String userInput = "";
        
        try {
            userInput = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println("Hello, " + userInput);
    }
}