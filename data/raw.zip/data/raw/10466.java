import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class PathTraversalVulnerability {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the file name to read:");
        String fileName = scanner.nextLine();
        
        File file = new File(fileName);
        
        if(file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                int content;
                while ((content = fis.read()) != -1) {
                    System.out.print((char) content);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("File not found.");
        }
        
        scanner.close();
    }
}