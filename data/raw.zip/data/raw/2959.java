import java.io.*;

public class XSSVulnerableCode {

    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter your name: ");
        String name = null;
        
        try {
            name = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println("Hello, " + name);
    }
}