import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;

public class InsecureDeserializationExample {

    public static void main(String[] args) {
        String serializedObject = "<malicious serialized object>"; // User input containing a malicious serialized object

        try {
            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(serializedObject.getBytes()));
            Object obj = ois.readObject();
            System.out.println("Deserialized object: " + obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}