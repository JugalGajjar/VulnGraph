import java.util.InputMismatchException;
import java.util.Scanner;

public class RomanNumeralConverter {

    private static final int[] VALUES = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static final String[] SYMBOLS = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static String toRoman(int number) {
        if (number < 1 || number > 3999) {
            throw new IllegalArgumentException("Number must be between 1 and 3999");
        }

        StringBuilder roman = new StringBuilder();
        for (int i = 0; i < VALUES.length; i++) {
            while (number >= VALUES[i]) {
                roman.append(SYMBOLS[i]);
                number -= VALUES[i];
            }
        }
        return roman.toString();
    }

    public static int fromRoman(String roman) {
        roman = roman.toUpperCase();
        int result = 0;
        int i = 0;
        while (i < roman.length()) {
            boolean found = false;
            for (int j = 0; j < SYMBOLS.length; j++) {
                if (roman.startsWith(SYMBOLS[j], i)) {
                    result += VALUES[j];
                    i += SYMBOLS[j].length();
                    found = true;
                    break;
                }
            }
            if (!found) {
                throw new IllegalArgumentException("Invalid Roman numeral: " + roman);
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Convert to Roman numeral");
            System.out.println("2. Convert from Roman numeral");
            System.out.println("3. Exit");
            try {
                System.out.print("Choose an option: ");
                int option = scanner.nextInt();
                switch (option) {
                    case 1:
                        System.out.print("Enter a number: ");
                        int number = scanner.nextInt();
                        System.out.println(toRoman(number));
                        break;
                    case 2:
                        System.out.print("Enter a Roman numeral: ");
                        String roman = scanner.next();
                        System.out.println(fromRoman(roman));
                        break;
                    case 3:
                        return;
                    default:
                        System.out.println("Invalid option");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input");
                scanner.next(); // Clear invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}