import java.util.*;

public class PasswordGenerator {
    private static final String LOWER_CASE = "abcdefghijklmnopqrstuvwxyz";
    private static final String UPPER_CASE = LOWER_CASE.toUpperCase();
    private static final String DIGITS = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$%^&*()_+";

    private static final Random random = new Random();

    public static String generatePassword(int length, boolean useUpperCase, boolean useDigits, boolean useSpecialChars) {
        if (length < 8) {
            throw new IllegalArgumentException("Password length must be at least 8 characters");
        }

        StringBuilder password = new StringBuilder(length);
        String chars = LOWER_CASE;

        if (useUpperCase) chars += UPPER_CASE;
        if (useDigits) chars += DIGITS;
        if (useSpecialChars) chars += SPECIAL_CHARS;

        if (useUpperCase) password.append(getRandomChar(UPPER_CASE));
        if (useDigits) password.append(getRandomChar(DIGITS));
        if (useSpecialChars) password.append(getRandomChar(SPECIAL_CHARS));

        for (int i = password.length(); i < length; i++) {
            password.append(getRandomChar(chars));
        }

        List<Character> passwordList = new ArrayList<>();
        for (char c : password.toString().toCharArray()) {
            passwordList.add(c);
        }
        Collections.shuffle(passwordList);

        StringBuilder shuffledPassword = new StringBuilder();
        for (char c : passwordList) {
            shuffledPassword.append(c);
        }

        return shuffledPassword.toString();
    }

    private static char getRandomChar(String chars) {
        return chars.charAt(random.nextInt(chars.length()));
    }

    public static void main(String[] args) {
        System.out.println(generatePassword(12, true, true, true));
    }
}