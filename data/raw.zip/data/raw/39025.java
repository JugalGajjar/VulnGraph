import java.math.BigDecimal;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the first number:");
            try {
                BigDecimal num1 = scanner.nextBigDecimal();
                System.out.println("Enter the operator (+, -, *, /):");
                String operator = scanner.next();
                System.out.println("Enter the second number:");
                BigDecimal num2 = scanner.nextBigDecimal();
                BigDecimal result = calculate(num1, operator, num2);
                System.out.println("Result: " + result);
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            } catch (ArithmeticException e) {
                System.out.println("Cannot divide by zero.");
            }
        }
    }

    private static BigDecimal calculate(BigDecimal num1, String operator, BigDecimal num2) {
        switch (operator) {
            case "+":
                return num1.add(num2);
            case "-":
                return num1.subtract(num2);
            case "*":
                return num1.multiply(num2);
            case "/":
                if (num2.compareTo(BigDecimal.ZERO) == 0) {
                    throw new ArithmeticException("Cannot divide by zero.");
                }
                return num1.divide(num2);
            default:
                throw new UnsupportedOperationException("Unsupported operator.");
        }
    }
}