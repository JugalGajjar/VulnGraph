import java.util.Scanner;

public class BufferOverflowExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        
        // Vulnerability: Improperly handling user input can lead to buffer overflow
        char[] buffer = new char[10];
        int length = Math.min(input.length(), buffer.length); // Ensure not to exceed buffer size
        
        for (int i = 0; i < length; i++) {
            buffer[i] = input.charAt(i);
        }
        
        System.out.println("Input successfully stored in buffer: " + new String(buffer));
    }
}