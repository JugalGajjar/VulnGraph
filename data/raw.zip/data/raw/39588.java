import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Enter the first number:");
                double num1 = scanner.nextDouble();
                System.out.println("Enter the operator (+, -, *, /):");
                String operator = scanner.next();
                System.out.println("Enter the second number:");
                double num2 = scanner.nextDouble();
                calculate(num1, num2, operator);
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            } catch (ArithmeticException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public static void calculate(double num1, double num2, String operator) {
        switch (operator) {
            case "+":
                System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
                break;
            case "-":
                System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
                break;
            case "*":
                System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
                break;
            case "/":
                if (num2 != 0) {
                    System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
                } else {
                    throw new ArithmeticException("Cannot divide by zero");
                }
                break;
            default:
                System.out.println("Invalid operator. Please enter +, -, * or /");
        }
    }
}