import java.sql.*;

public class SQLInjectionExample {
    public static void main(String[] args) {
        String userInput = "1 OR 1=1";
        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "username", "password");
            Statement stmt = conn.createStatement();
            
            String query = "SELECT * FROM users WHERE id = " + userInput;
            ResultSet rs = stmt.executeQuery(query);
            
            while(rs.next()) {
                System.out.println("User ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}