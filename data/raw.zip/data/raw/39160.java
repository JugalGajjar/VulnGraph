public final class RomanConverter {

    public static String toRoman(int value) {
        if (value <= 0 || value > 3999) {
            throw new IllegalArgumentException("Value outside valid range (1-3999)");
        }
        final int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        final String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            while (value >= values[i]) {
                sb.append(symbols[i]);
                value -= values[i];
            }
        }
        return sb.toString();
    }

    public static int fromRoman(String roman) {
        if (roman == null || roman.isEmpty()) {
            throw new IllegalArgumentException("Input must not be null or empty");
        }
        int total = 0;
        int prev = 0;
        for (char ch : new StringBuilder(roman).reverse().toString().toCharArray()) {
            int val = valueOf(ch);
            if (val < prev) {
                total -= val;
            } else {
                total += val;
            }
            prev = val;
        }
        String verify = toRoman(total);
        if (!verify.equalsIgnoreCase(roman)) {
            throw new IllegalArgumentException("Invalid Roman numeral");
        }
        return total;
    }

    private static int valueOf(char c) {
        switch (c) {
            case 'I': return 1;
            case 'V': return 5;
            case 'X': return 10;
            case 'L': return 50;
            case 'C': return 100;
            case 'D': return 500;
            case 'M': return 1000;
            default: throw new IllegalArgumentException("Invalid Roman numeral character: " + c);
        }
    }

    private RomanConverter() { }
}