import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = args[0]; // User input containing the file path
        String basePath = "/path/to/some/directory/"; // Base directory path
        
        // Concatenate the base directory path with the user input
        String filePath = basePath + userInput;

        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);

            int data;
            while ((data = fis.read()) != -1) {
                System.out.print((char) data);
            }

            fis.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}