import java.util.Objects;

public final class Money implements Comparable<Money> {
    private final long amountInCents;
    private final String currency;

    public Money(long amountInCents, String currency) {
        if (currency == null || currency.trim().isEmpty()) {
            throw new IllegalArgumentException("Currency must be non-empty.");
        }
        this.amountInCents = amountInCents;
        this.currency = currency.trim().toUpperCase();
    }

    public static Money of(long amountInCents, String currency) {
        return new Money(amountInCents, currency);
    }

    public long getAmountInCents() {
        return amountInCents;
    }

    public String getCurrency() {
        return currency;
    }

    public Money add(Money other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException("Currency mismatch: " + this.currency + " != " + other.currency);
        }
        return new Money(this.amountInCents + other.amountInCents, this.currency);
    }

    public Money subtract(Money other) {
        if (!this.currency.equals(other.currency)) {
            throw new IllegalArgumentException("Currency mismatch: " + this.currency + " != " + other.currency);
        }
        return new Money(this.amountInCents - other.amountInCents, this.currency);
    }

    @Override
    public int compareTo(Money o) {
        if (!this.currency.equals(o.currency)) {
            throw new IllegalArgumentException("Currency mismatch: " + this.currency + " != " + o.currency);
        }
        return Long.compare(this.amountInCents, o.amountInCents);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Money)) return false;
        Money money = (Money) o;
        return amountInCents == money.amountInCents && currency.equals(money.currency);
    }

    @Override
    public int hashCode() {
        return Objects.hash(amountInCents, currency);
    }

    @Override
    public String toString() {
        long abs = Math.abs(amountInCents);
        long major = abs / 100;
        long minor = abs % 100;
        return String.format("%s %s%d.%02d", currency, amountInCents < 0 ? "-" : "", major, minor);
    }
}