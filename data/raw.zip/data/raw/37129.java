package com.util;

import java.util.concurrent.ThreadLocalRandom;

public final class NanoId {

    private static final char[] ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_.~".toCharArray();
    private static final int DEFAULT_LENGTH = 21;

    private NanoId() { }

    public static String randomNanoId() {
        return randomNanoId(DEFAULT_LENGTH);
    }

    public static String randomNanoId(int length) {
        if (length <= 0) {
            throw new IllegalArgumentException("Length must be > 0");
        }
        char[] buf = new char[length];
        for (int i = 0; i < length; i++) {
            buf[i] = ALPHABET[ThreadLocalRandom.current().nextInt(ALPHABET.length)];
        }
        return new String(buf);
    }
}