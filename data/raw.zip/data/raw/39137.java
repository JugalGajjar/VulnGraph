import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

public final class TinyHttpClient {

    public static CompletableFuture<String> get(String url) {
        return CompletableFuture.supplyAsync(() -> {
            if (url == null || url.trim().isEmpty()) {
                throw new IllegalArgumentException("URL must not be null or empty");
            }
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int status = conn.getResponseCode();
                if (status >= 200 && status < 300) {
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }
                        return sb.toString();
                    }
                } else {
                    throw new IOException("HTTP error: " + status);
                }
            } catch (IOException e) {
                throw new RuntimeException("Request failed", e);
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        });
    }

    private TinyHttpClient() {}
}