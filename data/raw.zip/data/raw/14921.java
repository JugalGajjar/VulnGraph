import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionExample {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.print("Enter a file name: ");
        String fileName = br.readLine();
        
        // Vulnerability: User input is directly passed to the command without proper validation
        String command = "ls -l " + fileName;  // Assume user input is "myfile.txt; rm -rf /"
        
        Process process = Runtime.getRuntime().exec(command);
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
    }
}