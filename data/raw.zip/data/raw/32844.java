import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VulnerableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String userInput = request.getParameter("input");

        out.println("<html>");
        out.println("<body>");
        out.println("<h1>Hello, " + userInput + "</h1>"); // Vulnerability: user input is directly inserted into HTML response
        out.println("</body>");
        out.println("</html>");
    }
}