import java.io.IOException;
import java.io.PrintWriter;

public class XSSVulnerabilityDemo {

    public static void main(String[] args) {
        // Simulating user input
        String userInput = "<script>alert('XSS Attack!')</script>";

        // Improperly handling user input without proper encoding
        String output = "<h1>Welcome " + userInput + "</h1>";

        try {
            // Output the potentially malicious content to a web page
            PrintWriter out = new PrintWriter("index.html");
            out.println(output);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}