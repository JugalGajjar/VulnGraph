import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommandInjectionVulnerability {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter a command to execute: ");
        String command = reader.readLine();

        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec("ping -c 4 " + command);

        BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        
        while ((line = outputReader.readLine()) != null) {
            System.out.println(line);
        }
    }
}