import java.util.*;

public class UniqueWordsCounter {
    public static Map<String, Integer> countUniqueWords(String text) {
        if (text == null || text.isEmpty()) {
            return new HashMap<>();
        }

        String lowerCaseText = text.toLowerCase();
        String[] words = lowerCaseText.split("\\s+");

        Map<String, Integer> uniqueWords = new HashMap<>();
        for (String word : words) {
            if (word.matches("[a-z]+")) {
                uniqueWords.put(word, uniqueWords.getOrDefault(word, 0) + 1);
            }
        }

        return uniqueWords;
    }

    public static void main(String[] args) {
        try {
            System.out.println(countUniqueWords("This is a test string. This string is just for testing."));
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}