import java.time.Instant;
import java.util.Objects;

public final class TimestampedValue<T> implements Comparable<TimestampedValue<T>> {
    private final T value;
    private final Instant timestamp;

    private TimestampedValue(T value) {
        this.value = Objects.requireNonNull(value, "value must not be null");
        this.timestamp = Instant.now();
    }

    public static <T> TimestampedValue<T> of(T value) {
        return new TimestampedValue<>(value);
    }

    public T getValue() {
        return value;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TimestampedValue<?>)) return false;
        TimestampedValue<?> that = (TimestampedValue<?>) o;
        return value.equals(that.value) && timestamp.equals(that.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value, timestamp);
    }

    @Override
    public int compareTo(TimestampedValue<T> other) {
        Objects.requireNonNull(other, "other must not be null");
        int cmp = timestamp.compareTo(other.timestamp);
        return cmp != 0 ? cmp : Integer.compare(System.identityHashCode(this), System.identityHashCode(other));
    }

    @Override
    public String toString() {
        return "TimestampedValue{value=" + value + ", timestamp=" + timestamp + '}';
    }
}