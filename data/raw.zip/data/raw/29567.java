import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PathTraversalVulnerability {

    public static void main(String[] args) {
        String userInput = "../../../../../etc/passwd";
        String baseDir = "/var/www/html/";

        String fullPath = baseDir + userInput;

        try {
            File file = new File(fullPath);
            if (file.exists()) {
                byte[] fileData = Files.readAllBytes(Paths.get(file.getPath()));
                System.out.println(new String(fileData));
            } else {
                System.out.println("File not found");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}