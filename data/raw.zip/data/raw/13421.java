import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class XSSVulnerableServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userInput = request.getParameter("inputData");
        
        String output = "<p>User input: " + userInput + "</p>";
        
        PrintWriter out = response.getWriter();
        out.println(output);
    }
}